import os
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from config import Config
from app import db
from datetime import datetime
from sqlalchemy.dialects.postgresql import ENUM
from functools import wraps
from flask import Flask, jsonify
from flask_jwt_extended import get_jwt_identity, jwt_required

from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash

from db_models import User, Role, UserRole
from auth import role_required



from auth import jwt_required


import requests

from db_models import Expense, User


from werkzeug.security import check_password_hash
from flask_jwt_extended import create_access_token



db = SQLAlchemy()
jwt = JWTManager()

admin_bp = Blueprint('admin_bp', __name__)

@admin_bp.route('/create-user', methods=['POST'])
@role_required('Admin')


class Config:
    # PostgreSQL connection string
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'postgresql://user:password@localhost/expense_db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY') or 'your-secret-key-that-should-be-random-and-long' 
    from flask import Flask




def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    jwt.init_app(app)

    # Register blueprints for API routes
    from api.admin import admin_bp
    from api.employee import employee_bp
    from api.manager import manager_bp
    from api.public import public_bp
    
    app.register_blueprint(admin_bp, url_prefix='/api/admin')
    app.register_blueprint(employee_bp, url_prefix='/api/employee')
    app.register_blueprint(manager_bp, url_prefix='/api/manager')
    app.register_blueprint(public_bp, url_prefix='/api/public')

    with app.app_context():
        # Create database tables if they don't exist
        db.create_all()

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)


class User(db.Model):
    __tablename__ = 'users'
    user_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    manager_id = db.Column(db.Integer, db.ForeignKey('users.user_id'))
    
    roles = db.relationship('UserRole', backref='user', lazy=True)
    managed_employees = db.relationship('User', backref=db.backref('manager', remote_side=[user_id]), lazy=True)

class Role(db.Model):
    __tablename__ = 'roles'
    role_id = db.Column(db.Integer, primary_key=True)
    role_name = db.Column(db.String(50), unique=True, nullable=False)

class UserRole(db.Model):
    __tablename__ = 'user_roles'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'))
    role_id = db.Column(db.Integer, db.ForeignKey('roles.role_id'))

class Expense(db.Model):
    __tablename__ = 'expenses'
    expense_id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(255))
    category = db.Column(db.String(50))
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), nullable=False)
    status = db.Column(db.String(50), default='Draft')
    submitted_date = db.Column(db.DateTime, default=datetime.utcnow)
    submitter_id = db.Column(db.Integer, db.ForeignKey('users.user_id'))
    
    submitter = db.relationship('User', backref='submitted_expenses')



def role_required(role_name):
    def wrapper(fn):
        @wraps(fn)
        @jwt_required()
        def decorator(*args, **kwargs):
            current_user_id = get_jwt_identity()
            user_roles = UserRole.query.filter_by(user_id=current_user_id).all()
            
            for ur in user_roles:
                role = Role.query.get(ur.role_id)
                if role and role.role_name == role_name:
                    return fn(*args, **kwargs)
            
            return jsonify({"msg": "Permission denied"}), 403
        return decorator
    return wrapper





def create_user():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    role_name = data.get('role', 'Employee')
    manager_email = data.get('manager_email')

    if not all([email, password]):
        return jsonify({"msg": "Email and password are required"}), 400

    hashed_password = generate_password_hash(password)
    user_role = Role.query.filter_by(role_name=role_name).first()
    if not user_role:
        return jsonify({"msg": "Role not found"}), 404

    manager_id = None
    if manager_email:
        manager = User.query.filter_by(email=manager_email).first()
        if manager:
            manager_id = manager.user_id

    new_user = User(email=email, password_hash=hashed_password, manager_id=manager_id)
    db.session.add(new_user)
    db.session.commit()

    db.session.add(UserRole(user_id=new_user.user_id, role_id=user_role.role_id))
    db.session.commit()

    return jsonify({"msg": "User created successfully"}), 201

@admin_bp.route('/assign-manager', methods=['POST'])
@role_required('Admin')
def assign_manager():
    data = request.get_json()
    employee_email = data.get('employee_email')
    manager_email = data.get('manager_email')

    employee = User.query.filter_by(email=employee_email).first()
    manager = User.query.filter_by(email=manager_email).first()

    if not all([employee, manager]):
        return jsonify({"msg": "Employee or manager not found"}), 404
    
    employee.manager_id = manager.user_id
    db.session.commit()

    return jsonify({"msg": "Manager assigned successfully"}), 200




employee_bp = Blueprint('employee_bp', __name__)

@employee_bp.route('/submit-expense', methods=['POST'])
@jwt_required()
def submit_expense():
    data = request.get_json()
    current_user_id = get_jwt_identity()
    
    new_expense = Expense(
        description=data.get('description'),
        category=data.get('category'),
        amount=data.get('amount'),
        currency=data.get('currency'),
        status='Waiting approval',
        submitter_id=current_user_id
    )
    db.session.add(new_expense)
    db.session.commit()
    return jsonify({"msg": "Expense submitted successfully"}), 201

@employee_bp.route('/my-expenses', methods=['GET'])
@jwt_required()
def get_my_expenses():
    current_user_id = get_jwt_identity()
    expenses = Expense.query.filter_by(submitter_id=current_user_id).all()
    
    result = [{
        'id': e.expense_id,
        'description': e.description,
        'status': e.status
    } for e in expenses]
    
    return jsonify(result), 200



manager_bp = Blueprint('manager', __name__)

# You would need a separate service for real-time exchange rates
def get_exchange_rate(from_curr, to_curr):
    # This is a placeholder. In a real app, you'd call an API like Open Exchange Rates.
    # For now, let's assume a static rate.
    rates = {'USD': 1.0, 'EUR': 1.1, 'GBP': 1.25}
    if from_curr in rates and to_curr in rates:
        return rates[to_curr] / rates[from_curr]
    return 1.0

@manager_bp.route('/requests-to-review', methods=['GET'])
@role_required('Manager')
def get_requests_to_review():
    current_user_id = get_jwt_identity()
    managed_employees = User.query.filter_by(manager_id=current_user_id).all()
    managed_ids = [emp.user_id for emp in managed_employees]

    requests = Expense.query.filter(
        Expense.submitter_id.in_(managed_ids),
        Expense.status == 'Waiting approval'
    ).all()

    base_currency = 'USD' # Company's base currency
    result = []
    for req in requests:
        exchange_rate = get_exchange_rate(req.currency, base_currency)
        converted_amount = req.amount * exchange_rate
        result.append({
            'id': req.expense_id,
            'description': req.description,
            'amount': req.amount,
            'currency': req.currency,
            'converted_amount': converted_amount,
            'converted_currency': base_currency,
            'submitter': req.submitter.name
        })
    return jsonify(result), 200

@manager_bp.route('/approve-expense/<int:expense_id>', methods=['POST'])
@role_required('Manager')
def approve_expense(expense_id):
    current_user_id = get_jwt_identity()
    expense = Expense.query.get_or_404(expense_id)

    # Check if the manager is authorized to approve this expense
    if expense.submitter.manager_id != current_user_id:
        return jsonify({"msg": "Forbidden"}), 403

    expense.status = 'Approved'
    db.session.commit()
    return jsonify({"msg": "Expense approved"}), 200



public_bp = Blueprint('public', __name__)

@public_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')

    user = User.query.filter_by(email=email).first()
    if not user or not check_password_hash(user.password_hash, password):
        return jsonify({"msg": "Bad username or password"}), 401

    roles = UserRole.query.filter_by(user_id=user.user_id).all()
    role_names = [Role.query.get(r.role_id).role_name for r in roles]

    access_token = create_access_token(identity=user.user_id, additional_claims={"roles": role_names})
    return jsonify(access_token=access_token)



from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from config import Config

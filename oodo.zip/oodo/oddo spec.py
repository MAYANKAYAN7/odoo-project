import os
import re
import pytesseract
import pandas as pd
from io import BytesIO
from PIL import Image
from datetime import datetime
from functools import wraps
from flask import (
    Flask, request, jsonify, Blueprint, send_file
)
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import (
    JWTManager, jwt_required, get_jwt_identity, create_access_token
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask_mail import Mail, Message

# ===============================================================
# CONFIGURATION
# ===============================================================
class Config:
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL") or "sqlite:///expense_mgmt.db"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY") or "super-secret-key"
    UPLOAD_FOLDER = "/tmp"

    # Email setup (you can change to SMTP credentials)
    MAIL_SERVER = os.environ.get("MAIL_SERVER", "smtp.gmail.com")
    MAIL_PORT = int(os.environ.get("MAIL_PORT", 587))
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME", "noreply.managementapp@gmail.com")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD", "yourpassword")
    MAIL_DEFAULT_SENDER = MAIL_USERNAME


db = SQLAlchemy()
jwt = JWTManager()
mail = Mail()


# ===============================================================
# DATABASE MODELS
# ===============================================================
class User(db.Model):
    __tablename__ = "users"
    user_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80))
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    manager_id = db.Column(db.Integer, db.ForeignKey("users.user_id"))

    roles = db.relationship("UserRole", backref="user", lazy=True)
    managed_employees = db.relationship("User", backref=db.backref("manager", remote_side=[user_id]), lazy=True)


class Role(db.Model):
    __tablename__ = "roles"
    role_id = db.Column(db.Integer, primary_key=True)
    role_name = db.Column(db.String(50), unique=True, nullable=False)


class UserRole(db.Model):
    __tablename__ = "user_roles"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.user_id"))
    role_id = db.Column(db.Integer, db.ForeignKey("roles.role_id"))


class Expense(db.Model):
    __tablename__ = "expenses"
    expense_id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(255))
    category = db.Column(db.String(50))
    amount = db.Column(db.Float)
    currency = db.Column(db.String(3))
    status = db.Column(db.String(50), default="Draft")
    submitted_date = db.Column(db.DateTime, default=datetime.utcnow)
    approved_date = db.Column(db.DateTime, nullable=True)
    submitter_id = db.Column(db.Integer, db.ForeignKey("users.user_id"))
    manager_comment = db.Column(db.String(255))

    submitter = db.relationship("User", backref="submitted_expenses")


class ApprovalRule(db.Model):
    __tablename__ = "approval_rules"
    rule_id = db.Column(db.Integer, primary_key=True)
    level = db.Column(db.Integer)
    rule_type = db.Column(db.String(50))  # percentage, specific, hybrid
    min_amount = db.Column(db.Float)
    max_amount = db.Column(db.Float)
    category = db.Column(db.String(50))
    approver_id = db.Column(db.Integer, db.ForeignKey("users.user_id"))

    approver = db.relationship("User", backref="approval_rules")


class ApprovalHistory(db.Model):
    __tablename__ = "approval_history"
    history_id = db.Column(db.Integer, primary_key=True)
    expense_id = db.Column(db.Integer, db.ForeignKey("expenses.expense_id"))
    action = db.Column(db.String(50))
    actor_id = db.Column(db.Integer, db.ForeignKey("users.user_id"))
    comment = db.Column(db.String(255))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    expense = db.relationship("Expense", backref="history")
    actor = db.relationship("User")


# ===============================================================
# HELPER FUNCTIONS
# ===============================================================
def role_required(role_name):
    def wrapper(fn):
        @wraps(fn)
        @jwt_required()
        def decorator(*args, **kwargs):
            current_user_id = get_jwt_identity()
            roles = [
                Role.query.get(ur.role_id).role_name
                for ur in UserRole.query.filter_by(user_id=current_user_id)
            ]
            if role_name in roles:
                return fn(*args, **kwargs)
            return jsonify({"msg": "Permission denied"}), 403
        return decorator
    return wrapper


def log_history(expense_id, action, actor_id, comment=None):
    db.session.add(ApprovalHistory(
        expense_id=expense_id, action=action, actor_id=actor_id, comment=comment
    ))
    db.session.commit()


def send_email(to, subject, body):
    """Send email notification."""
    msg = Message(subject, recipients=[to])
    msg.body = body
    try:
        mail.send(msg)
    except Exception as e:
        print(f"Email failed: {e}")


def get_next_approver(expense):
    """Determine next approver dynamically based on stacked rules."""
    applicable_rules = ApprovalRule.query.order_by(ApprovalRule.level.asc()).all()
    for rule in applicable_rules:
        if rule.rule_type == "percentage":
            if rule.min_amount <= expense.amount <= (rule.max_amount or float("inf")):
                return rule.approver
        elif rule.rule_type == "specific":
            if expense.category == rule.category:
                return rule.approver
        elif rule.rule_type == "hybrid":
            if (
                (rule.min_amount and expense.amount >= rule.min_amount)
                and (expense.category == rule.category)
            ):
                return rule.approver
    return None


# ===============================================================
# BLUEPRINTS
# ===============================================================
admin_bp = Blueprint("admin_bp", __name__)
employee_bp = Blueprint("employee_bp", __name__)
manager_bp = Blueprint("manager_bp", __name__)
public_bp = Blueprint("public_bp", __name__)


# ===============================================================
# ADMIN ENDPOINTS
# ===============================================================
@admin_bp.route("/create-user", methods=["POST"])
@role_required("Admin")
def create_user():
    data = request.get_json()
    email, password, role_name = data.get("email"), data.get("password"), data.get("role", "Employee")
    manager_email = data.get("manager_email")

    hashed = generate_password_hash(password)
    role = Role.query.filter_by(role_name=role_name).first()
    manager_id = None
    if manager_email:
        manager = User.query.filter_by(email=manager_email).first()
        if manager:
            manager_id = manager.user_id

    user = User(email=email, password_hash=hashed, manager_id=manager_id)
    db.session.add(user)
    db.session.commit()

    db.session.add(UserRole(user_id=user.user_id, role_id=role.role_id))
    db.session.commit()
    return jsonify({"msg": "User created successfully"}), 201


@admin_bp.route("/create-approval-rule", methods=["POST"])
@role_required("Admin")
def create_approval_rule():
    data = request.get_json()
    rule = ApprovalRule(
        level=data.get("level"),
        rule_type=data.get("rule_type"),
        min_amount=data.get("min_amount"),
        max_amount=data.get("max_amount"),
        category=data.get("category"),
        approver_id=data.get("approver_id"),
    )
    db.session.add(rule)
    db.session.commit()
    return jsonify({"msg": "Approval rule added successfully"}), 201


@admin_bp.route("/expense-report/export", methods=["GET"])
@role_required("Admin")
def export_report():
    fmt = request.args.get("format", "csv").lower()
    expenses = Expense.query.all()

    df = pd.DataFrame([{
        "ID": e.expense_id,
        "Description": e.description,
        "Category": e.category,
        "Amount": e.amount,
        "Currency": e.currency,
        "Status": e.status,
        "Submitter": e.submitter.email if e.submitter else None,
        "Submitted": e.submitted_date,
        "Approved": e.approved_date,
    } for e in expenses])

    output = BytesIO()
    if fmt == "excel":
        with pd.ExcelWriter(output, engine="openpyxl") as writer:
            df.to_excel(writer, index=False)
        filename = "expense_report.xlsx"
    else:
        df.to_csv(output, index=False)
        filename = "expense_report.csv"

    output.seek(0)
    return send_file(output, as_attachment=True, download_name=filename)


# ===============================================================
# EMPLOYEE OCR RECEIPT UPLOAD
# ===============================================================
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg"}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@employee_bp.route("/upload-receipt", methods=["POST"])
@jwt_required()
def upload_receipt():
    if "file" not in request.files:
        return jsonify({"msg": "No file uploaded"}), 400

    file = request.files["file"]
    if not allowed_file(file.filename):
        return jsonify({"msg": "Invalid file type"}), 400

    filepath = os.path.join(Config.UPLOAD_FOLDER, secure_filename(file.filename))
    file.save(filepath)

    text = pytesseract.image_to_string(Image.open(filepath))
    extracted = {}

    if amount := re.search(r"(\d+\.\d{2})", text):
        extracted["amount"] = float(amount.group(1))
    if date := re.search(r"(\d{2}[/-]\d{2}[/-]\d{4})", text):
        extracted["date"] = date.group(1)
    if mgmt := re.search(r"([A-Za-z\s]+(?:Management|Office|Company))", text, re.IGNORECASE):
        extracted["management_name"] = mgmt.group(1)

    current_user = get_jwt_identity()
    expense = Expense(
        description="Auto OCR Management Expense",
        category="Auto-OCR",
        amount=extracted.get("amount"),
        currency="USD",
        submitter_id=current_user,
        status="Waiting approval"
    )
    db.session.add(expense)
    db.session.commit()

    next_approver = get_next_approver(expense)
    if next_approver:
        send_email(
            next_approver.email,
            "New Expense Approval Request",
            f"A new expense (ID: {expense.expense_id}) is waiting for your approval."
        )

    log_history(expense.expense_id, "Uploaded Receipt", current_user, "Auto-created via OCR")
    return jsonify({"msg": "Receipt processed", "fields": extracted, "draft_expense_id": expense.expense_id}), 200


# ===============================================================
# MANAGER APPROVAL
# ===============================================================
@manager_bp.route("/approve-expense/<int:expense_id>", methods=["POST"])
@role_required("Manager")
def approve_expense(expense_id):
    data = request.get_json()
    comment = data.get("comment", "")
    current_user = get_jwt_identity()

    expense = Expense.query.get_or_404(expense_id)
    next_approver = get_next_approver(expense)

    if next_approver and next_approver.user_id != current_user:
        expense.status = f"Waiting for {next_approver.email}"
        log_history(expense.expense_id, "Forwarded", current_user, f"Forwarded to {next_approver.email}")
        send_email(next_approver.email, "Expense Forwarded for Approval",
                   f"Expense ID {expense.expense_id} has been forwarded to you.")
    else:
        expense.status = "Approved"
        expense.approved_date = datetime.utcnow()
        log_history(expense.expense_id, "Approved", current_user, comment)
        send_email(expense.submitter.email, "Expense Approved",
                   f"Your expense ID {expense.expense_id} has been approved.")

    db.session.commit()
    return jsonify({"msg": "Expense processed successfully"}), 200


# ===============================================================
# AUTHENTICATION
# ===============================================================
@public_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    email, password = data.get("email"), data.get("password")
    user = User.query.filter_by(email=email).first()

    if not user or not check_password_hash(user.password_hash, password):
        return jsonify({"msg": "Invalid credentials"}), 401

    roles = [
        Role.query.get(ur.role_id).role_name for ur in UserRole.query.filter_by(user_id=user.user_id)
    ]
    token = create_access_token(identity=user.user_id, additional_claims={"roles": roles})
    return jsonify(access_token=token)


# ===============================================================
# APP FACTORY
# ===============================================================
def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)
    jwt.init_app(app)
    mail.init_app(app)

    app.register_blueprint(admin_bp, url_prefix="/api/admin")
    app.register_blueprint(employee_bp, url_prefix="/api/employee")
    app.register_blueprint(manager_bp, url_prefix="/api/manager")
    app.register_blueprint(public_bp, url_prefix="/api/public")

    with app.app_context():
        db.create_all()

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)

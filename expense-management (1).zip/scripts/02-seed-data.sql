-- Insert default admin user (password: admin123)
INSERT INTO users (id, email, password_hash, name, role, department, created_at, updated_at)
VALUES 
  ('1', 'admin@company.com', '$2a$10$rKZLvVZQxQxQxQxQxQxQxO', 'Admin User', 'admin', 'Administration', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('2', 'manager@company.com', '$2a$10$rKZLvVZQxQxQxQxQxQxQxO', 'Manager User', 'manager', 'Sales', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('3', 'employee@company.com', '$2a$10$rKZLvVZQxQxQxQxQxQxQxO', 'Employee User', 'employee', 'Sales', '2', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
ON CONFLICT (id) DO NOTHING;

-- Insert default settings
INSERT INTO settings (id, company_name, default_currency, supported_currencies, max_expense_amount, require_receipts, receipt_required_amount, auto_approval_threshold, fiscal_year_start, notification_email, updated_at)
VALUES (
  1,
  'Acme Corporation',
  'USD',
  ARRAY['USD', 'EUR', 'GBP', 'JPY'],
  10000.00,
  true,
  100.00,
  50.00,
  '01-01',
  'finance@company.com',
  CURRENT_TIMESTAMP
)
ON CONFLICT (id) DO UPDATE SET
  company_name = EXCLUDED.company_name,
  default_currency = EXCLUDED.default_currency,
  supported_currencies = EXCLUDED.supported_currencies,
  max_expense_amount = EXCLUDED.max_expense_amount,
  require_receipts = EXCLUDED.require_receipts,
  receipt_required_amount = EXCLUDED.receipt_required_amount,
  auto_approval_threshold = EXCLUDED.auto_approval_threshold,
  fiscal_year_start = EXCLUDED.fiscal_year_start,
  notification_email = EXCLUDED.notification_email,
  updated_at = CURRENT_TIMESTAMP;

-- Insert sample expenses
INSERT INTO expenses (id, employee_id, employee_name, amount, currency, category, description, date, status, created_at, updated_at)
VALUES 
  ('exp-1', '3', 'Employee User', 150.00, 'USD', 'meals', 'Client dinner', CURRENT_TIMESTAMP - INTERVAL '2 days', 'pending', CURRENT_TIMESTAMP - INTERVAL '2 days', CURRENT_TIMESTAMP - INTERVAL '2 days'),
  ('exp-2', '3', 'Employee User', 500.00, 'USD', 'travel', 'Flight to conference', CURRENT_TIMESTAMP - INTERVAL '5 days', 'approved', CURRENT_TIMESTAMP - INTERVAL '5 days', CURRENT_TIMESTAMP - INTERVAL '4 days'),
  ('exp-3', '3', 'Employee User', 75.00, 'USD', 'office_supplies', 'Office supplies', CURRENT_TIMESTAMP - INTERVAL '1 day', 'draft', CURRENT_TIMESTAMP - INTERVAL '1 day', CURRENT_TIMESTAMP - INTERVAL '1 day')
ON CONFLICT (id) DO NOTHING;

-- Insert approval steps for the expenses
INSERT INTO approval_steps (expense_id, approver_id, approver_name, status, step_order, timestamp)
VALUES 
  ('exp-1', '2', 'Manager User', 'pending', 1, NULL),
  ('exp-2', '2', 'Manager User', 'approved', 1, CURRENT_TIMESTAMP - INTERVAL '4 days')
ON CONFLICT DO NOTHING;

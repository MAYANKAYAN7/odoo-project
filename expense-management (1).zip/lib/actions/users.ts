"use server"

import { revalidatePath } from "next/cache"
import { db } from "../server/db"
import { getCurrentUser } from "./auth"
import type { User, UserRole } from "../types"

export async function getUsers() {
  const user = await getCurrentUser()
  if (!user || user.role !== "admin") {
    throw new Error("Unauthorized")
  }

  return await db.users.findAll()
}

export async function getUserById(id: string) {
  const user = await getCurrentUser()
  if (!user) {
    throw new Error("Unauthorized")
  }

  return await db.users.findById(id)
}

export async function getManagers() {
  const users = await db.users.findAll()
  return users.filter((u) => u.role === "manager")
}

export async function createUser(data: {
  email: string
  name: string
  role: UserRole
  department?: string
  managerId?: string
}) {
  const user = await getCurrentUser()
  if (!user || user.role !== "admin") {
    throw new Error("Unauthorized")
  }

  const newUser: User = {
    id: `user-${Date.now()}`,
    ...data,
    createdAt: new Date(),
    updatedAt: new Date(),
  }

  await db.users.create(newUser)
  revalidatePath("/admin")

  return { success: true, user: newUser }
}

export async function updateUser(id: string, data: Partial<User>) {
  const user = await getCurrentUser()
  if (!user || user.role !== "admin") {
    throw new Error("Unauthorized")
  }

  await db.users.update(id, data)
  revalidatePath("/admin")

  return { success: true }
}

export async function deleteUser(id: string) {
  const user = await getCurrentUser()
  if (!user || user.role !== "admin") {
    throw new Error("Unauthorized")
  }

  await db.users.delete(id)
  revalidatePath("/admin")

  return { success: true }
}

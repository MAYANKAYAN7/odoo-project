"use server"

import { revalidatePath } from "next/cache"
import { db } from "../server/db"
import { getCurrentUser } from "./auth"
import type { Expense, ExpenseCategory, ApprovalStep } from "../types"

export async function getExpenses() {
  const user = await getCurrentUser()
  if (!user) {
    throw new Error("Unauthorized")
  }

  const expenses = await db.expenses.findAll()

  // Filter based on user role
  if (user.role === "employee") {
    return expenses.filter((e) => e.employeeId === user.id)
  } else if (user.role === "manager") {
    // Return expenses where manager has pending approval or from their team
    return expenses.filter(
      (e) => e.approvalChain.some((step) => step.approverId === user.id) || e.employeeId === user.id,
    )
  }

  // Admin sees all
  return expenses
}

export async function getExpenseById(id: string) {
  const user = await getCurrentUser()
  if (!user) {
    throw new Error("Unauthorized")
  }

  const expense = await db.expenses.findById(id)
  if (!expense) {
    return null
  }

  // Check permissions
  if (user.role === "employee" && expense.employeeId !== user.id) {
    throw new Error("Unauthorized")
  }

  return expense
}

export async function createExpense(data: {
  amount: number
  category: ExpenseCategory
  description: string
  date: Date
  managerId: string
}) {
  const user = await getCurrentUser()
  if (!user || user.role !== "employee") {
    throw new Error("Unauthorized")
  }

  const manager = await db.users.findById(data.managerId)
  if (!manager) {
    throw new Error("Manager not found")
  }

  const newExpense: Expense = {
    id: `exp-${Date.now()}`,
    employeeId: user.id,
    employeeName: user.name,
    amount: data.amount,
    currency: "USD",
    category: data.category,
    description: data.description,
    date: data.date,
    status: "pending",
    approvalChain: [
      {
        approverId: data.managerId,
        approverName: manager.name,
        status: "pending",
      },
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
  }

  await db.expenses.create(newExpense)
  revalidatePath("/employee")
  revalidatePath("/manager")

  return { success: true, expense: newExpense }
}

export async function approveExpense(expenseId: string, comments?: string) {
  const user = await getCurrentUser()
  if (!user) {
    throw new Error("Unauthorized")
  }

  const expense = await db.expenses.findById(expenseId)
  if (!expense) {
    throw new Error("Expense not found")
  }

  // Find the approval step for this user
  const approvalStep = expense.approvalChain.find((step) => step.approverId === user.id && step.status === "pending")

  if (!approvalStep && user.role !== "admin") {
    throw new Error("Not authorized to approve this expense")
  }

  // Update approval chain
  const updatedChain = expense.approvalChain.map((step) =>
    step.approverId === user.id
      ? {
          ...step,
          status: "approved" as const,
          comments,
          timestamp: new Date(),
        }
      : step,
  )

  // Check if all approvals are complete
  const allApproved = updatedChain.every((step) => step.status === "approved")

  await db.expenses.update(expenseId, {
    approvalChain: updatedChain,
    status: allApproved ? "approved" : "pending",
  })

  revalidatePath("/manager")
  revalidatePath("/admin")

  return { success: true }
}

export async function rejectExpense(expenseId: string, comments: string) {
  const user = await getCurrentUser()
  if (!user) {
    throw new Error("Unauthorized")
  }

  const expense = await db.expenses.findById(expenseId)
  if (!expense) {
    throw new Error("Expense not found")
  }

  // Find the approval step for this user
  const approvalStep = expense.approvalChain.find((step) => step.approverId === user.id && step.status === "pending")

  if (!approvalStep && user.role !== "admin") {
    throw new Error("Not authorized to reject this expense")
  }

  // Update approval chain
  const updatedChain = expense.approvalChain.map((step) =>
    step.approverId === user.id
      ? {
          ...step,
          status: "rejected" as const,
          comments,
          timestamp: new Date(),
        }
      : step,
  )

  await db.expenses.update(expenseId, {
    approvalChain: updatedChain,
    status: "rejected",
  })

  revalidatePath("/manager")
  revalidatePath("/admin")
  revalidatePath("/employee")

  return { success: true }
}

export async function overrideExpenseStatus(
  expenseId: string,
  newStatus: "approved" | "rejected" | "pending",
  comments: string,
) {
  const user = await getCurrentUser()
  if (!user || user.role !== "admin") {
    throw new Error("Unauthorized - Admin only")
  }

  const expense = await db.expenses.findById(expenseId)
  if (!expense) {
    throw new Error("Expense not found")
  }

  // Add admin override to approval chain
  const overrideStep: ApprovalStep = {
    approverId: user.id,
    approverName: `${user.name} (Admin Override)`,
    status: newStatus === "approved" ? "approved" : "rejected",
    comments: `[ADMIN OVERRIDE] ${comments}`,
    timestamp: new Date(),
  }

  await db.expenses.update(expenseId, {
    status: newStatus,
    approvalChain: [...expense.approvalChain, overrideStep],
  })

  revalidatePath("/admin")
  revalidatePath("/manager")
  revalidatePath("/employee")

  return { success: true }
}

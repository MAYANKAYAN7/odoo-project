"use server"

import { cookies } from "next/headers"
import { db } from "../server/db"
import type { User } from "../types"

// Simple session management (in production, use proper authentication)
export async function login(email: string, password: string) {
  // In production, verify password hash
  const user = await db.users.findByEmail(email)

  if (!user) {
    return { success: false, error: "Invalid credentials" }
  }

  // Create session (in production, use JWT or session tokens)
  const cookieStore = await cookies()
  cookieStore.set("user_id", user.id, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7, // 7 days
  })

  return { success: true, user }
}

export async function logout() {
  const cookieStore = await cookies()
  cookieStore.delete("user_id")
  return { success: true }
}

export async function getCurrentUser(): Promise<User | null> {
  const cookieStore = await cookies()
  const userId = cookieStore.get("user_id")?.value

  if (!userId) {
    return null
  }

  const user = await db.users.findById(userId)
  return user || null
}

export async function signup(email: string, password: string, name: string, role: "employee" | "manager") {
  // Check if user already exists
  const existingUser = await db.users.findByEmail(email)
  if (existingUser) {
    return { success: false, error: "User already exists" }
  }

  // Create new user
  const newUser: User = {
    id: `user-${Date.now()}`,
    email,
    name,
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
  }

  await db.users.create(newUser)

  // Auto login
  const cookieStore = await cookies()
  cookieStore.set("user_id", newUser.id, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7,
  })

  return { success: true, user: newUser }
}

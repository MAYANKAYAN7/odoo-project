import type { User, Expense, ApprovalRule, AuditLog, Settings } from "./types"

// Mock users data
export const mockUsers: User[] = [
  {
    id: "1",
    email: "admin@company.com",
    name: "Admin User",
    role: "admin",
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "2",
    email: "manager@company.com",
    name: "Sarah Johnson",
    role: "manager",
    department: "Engineering",
    createdAt: new Date("2024-01-15"),
    updatedAt: new Date("2024-01-15"),
  },
  {
    id: "3",
    email: "employee@company.com",
    name: "John Smith",
    role: "employee",
    department: "Engineering",
    managerId: "2",
    createdAt: new Date("2024-02-01"),
    updatedAt: new Date("2024-02-01"),
  },
  {
    id: "4",
    email: "jane.doe@company.com",
    name: "Jane Doe",
    role: "employee",
    department: "Marketing",
    managerId: "5",
    createdAt: new Date("2024-02-10"),
    updatedAt: new Date("2024-02-10"),
  },
  {
    id: "5",
    email: "mike.wilson@company.com",
    name: "Mike Wilson",
    role: "manager",
    department: "Marketing",
    createdAt: new Date("2024-01-20"),
    updatedAt: new Date("2024-01-20"),
  },
  {
    id: "6",
    email: "jane.smith@company.com",
    name: "Jane Smith",
    role: "employee",
    department: "Marketing",
    managerId: "5",
    createdAt: new Date("2025-01-14"),
    updatedAt: new Date("2025-01-14"),
  },
]

// Mock expenses data
export const mockExpenses: Expense[] = [
  {
    id: "exp-1",
    employeeId: "3",
    employeeName: "John Smith",
    amount: 250.0,
    currency: "USD",
    category: "meals",
    description: "Client dinner meeting",
    date: new Date("2024-03-15"),
    status: "pending",
    approvalChain: [
      {
        approverId: "2",
        approverName: "Sarah Johnson",
        status: "pending",
      },
    ],
    createdAt: new Date("2024-03-16"),
    updatedAt: new Date("2024-03-16"),
  },
  {
    id: "exp-2",
    employeeId: "4",
    employeeName: "Jane Doe",
    amount: 1500.0,
    currency: "USD",
    category: "travel",
    description: "Conference travel expenses",
    date: new Date("2024-03-10"),
    status: "approved",
    approvalChain: [
      {
        approverId: "5",
        approverName: "Mike Wilson",
        status: "approved",
        comments: "Approved for marketing conference",
        timestamp: new Date("2024-03-11"),
      },
    ],
    createdAt: new Date("2024-03-11"),
    updatedAt: new Date("2024-03-11"),
  },
  {
    id: "exp-3",
    employeeId: "6",
    employeeName: "Jane Smith",
    amount: 300.0,
    currency: "USD",
    category: "office_supplies",
    description: "Office supplies",
    date: new Date("2025-01-12"),
    status: "rejected",
    approvalChain: [
      {
        approverId: "5",
        approverName: "Mike Wilson",
        status: "rejected",
        comments: "Missing receipt",
        timestamp: new Date("2025-01-12"),
      },
    ],
    createdAt: new Date("2025-01-12"),
    updatedAt: new Date("2025-01-12"),
  },
]

// Mock approval rules
export const mockApprovalRules: ApprovalRule[] = [
  {
    id: "rule-1",
    name: "High Value Expenses",
    priority: 1,
    conditions: [
      {
        type: "amount_greater_than",
        value: 1000,
      },
    ],
    approvers: ["1", "2"],
    requireAllApprovals: true,
    isActive: true,
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2025-01-13"),
  },
  {
    id: "rule-2",
    name: "Travel Expenses",
    priority: 2,
    conditions: [
      {
        type: "category_equals",
        value: "travel",
      },
    ],
    approvers: ["2"],
    requireAllApprovals: false,
    isActive: true,
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
]

// Mock audit logs
export const mockAuditLogs: AuditLog[] = [
  {
    id: "log-1",
    userId: "1",
    userName: "Admin User",
    action: "create",
    entityType: "expense",
    entityId: "exp-1",
    details: "Created expense: Flight to NYC",
    timestamp: new Date("2025-01-15T10:30:00"),
    ipAddress: "192.168.1.100",
  },
  {
    id: "log-2",
    userId: "2",
    userName: "Sarah Johnson",
    action: "approve",
    entityType: "expense",
    entityId: "exp-1",
    details: "Approved expense: Flight to NYC",
    timestamp: new Date("2025-01-15T14:20:00"),
    ipAddress: "192.168.1.101",
  },
  {
    id: "log-3",
    userId: "1",
    userName: "Admin User",
    action: "create",
    entityType: "user",
    entityId: "6",
    details: "Created new user: Jane Smith",
    timestamp: new Date("2025-01-14T09:15:00"),
    ipAddress: "192.168.1.100",
  },
  {
    id: "log-4",
    userId: "1",
    userName: "Admin User",
    action: "update",
    entityType: "approval_rule",
    entityId: "rule-1",
    details: "Updated approval rule: High Value Expenses",
    timestamp: new Date("2025-01-13T16:45:00"),
    ipAddress: "192.168.1.100",
  },
  {
    id: "log-5",
    userId: "5",
    userName: "Mike Wilson",
    action: "reject",
    entityType: "expense",
    entityId: "exp-3",
    details: "Rejected expense: Office supplies - Missing receipt",
    timestamp: new Date("2025-01-12T11:30:00"),
    ipAddress: "192.168.1.102",
  },
]

// Mock settings
export const mockSettings: Settings = {
  companyName: "Acme Corporation",
  defaultCurrency: "USD",
  supportedCurrencies: ["USD", "EUR", "GBP", "JPY"],
  maxExpenseAmount: 10000,
  requireReceipts: true,
  receiptRequiredAmount: 50,
  autoApprovalThreshold: 25,
  fiscalYearStart: "01-01",
  notificationEmail: "expenses@company.com",
  updatedAt: new Date("2024-01-01"),
}

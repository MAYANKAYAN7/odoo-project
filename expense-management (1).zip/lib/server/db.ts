// PostgreSQL database connection and operations
import { neon } from "@neondatabase/serverless"
import type { User, Expense, ApprovalRule, AuditLog, Settings } from "../types"

const sql = neon(process.env.DATABASE_URL || "")

// Helper function to convert database rows to User objects
function rowToUser(row: any): User {
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    role: row.role,
    department: row.department,
    managerId: row.manager_id,
    profilePhoto: row.profile_photo,
    phone: row.phone,
    createdAt: new Date(row.created_at),
    updatedAt: new Date(row.updated_at),
  }
}

// Helper function to convert database rows to Expense objects
async function rowToExpense(row: any): Promise<Expense> {
  // Fetch approval steps for this expense
  const approvalSteps = await sql`
    SELECT * FROM approval_steps 
    WHERE expense_id = ${row.id} 
    ORDER BY step_order ASC
  `

  return {
    id: row.id,
    employeeId: row.employee_id,
    employeeName: row.employee_name,
    amount: Number.parseFloat(row.amount),
    currency: row.currency,
    category: row.category,
    description: row.description,
    date: new Date(row.date),
    status: row.status,
    receiptUrl: row.receipt_url,
    approvalChain: approvalSteps.map((step: any) => ({
      approverId: step.approver_id,
      approverName: step.approver_name,
      status: step.status,
      comments: step.comments,
      timestamp: step.timestamp ? new Date(step.timestamp) : undefined,
    })),
    createdAt: new Date(row.created_at),
    updatedAt: new Date(row.updated_at),
  }
}

export const db = {
  users: {
    findAll: async (): Promise<User[]> => {
      const rows = await sql`SELECT * FROM users ORDER BY created_at DESC`
      return rows.map(rowToUser)
    },
    findById: async (id: string): Promise<User | undefined> => {
      const rows = await sql`SELECT * FROM users WHERE id = ${id}`
      return rows.length > 0 ? rowToUser(rows[0]) : undefined
    },
    findByEmail: async (email: string): Promise<User | undefined> => {
      const rows = await sql`SELECT * FROM users WHERE email = ${email}`
      return rows.length > 0 ? rowToUser(rows[0]) : undefined
    },
    create: async (user: User): Promise<User> => {
      await sql`
        INSERT INTO users (id, email, password_hash, name, role, department, manager_id, profile_photo, phone, created_at, updated_at)
        VALUES (${user.id}, ${user.email}, 'temp_hash', ${user.name}, ${user.role}, ${user.department || null}, ${user.managerId || null}, ${user.profilePhoto || null}, ${user.phone || null}, ${user.createdAt}, ${user.updatedAt})
      `
      return user
    },
    update: async (id: string, data: Partial<User>): Promise<User | undefined> => {
      const updates: string[] = []
      const values: any[] = []

      if (data.name !== undefined) {
        updates.push(`name = $${updates.length + 1}`)
        values.push(data.name)
      }
      if (data.email !== undefined) {
        updates.push(`email = $${updates.length + 1}`)
        values.push(data.email)
      }
      if (data.role !== undefined) {
        updates.push(`role = $${updates.length + 1}`)
        values.push(data.role)
      }
      if (data.department !== undefined) {
        updates.push(`department = $${updates.length + 1}`)
        values.push(data.department)
      }
      if (data.managerId !== undefined) {
        updates.push(`manager_id = $${updates.length + 1}`)
        values.push(data.managerId)
      }

      updates.push(`updated_at = CURRENT_TIMESTAMP`)

      if (updates.length === 1) return db.users.findById(id)

      await sql`UPDATE users SET ${sql(updates.join(", "))} WHERE id = ${id}`
      return db.users.findById(id)
    },
    delete: async (id: string): Promise<boolean> => {
      const result = await sql`DELETE FROM users WHERE id = ${id}`
      return result.count > 0
    },
  },
  expenses: {
    findAll: async (): Promise<Expense[]> => {
      const rows = await sql`SELECT * FROM expenses ORDER BY created_at DESC`
      return Promise.all(rows.map(rowToExpense))
    },
    findById: async (id: string): Promise<Expense | undefined> => {
      const rows = await sql`SELECT * FROM expenses WHERE id = ${id}`
      return rows.length > 0 ? rowToExpense(rows[0]) : undefined
    },
    findByEmployeeId: async (employeeId: string): Promise<Expense[]> => {
      const rows = await sql`SELECT * FROM expenses WHERE employee_id = ${employeeId} ORDER BY created_at DESC`
      return Promise.all(rows.map(rowToExpense))
    },
    findByStatus: async (status: string): Promise<Expense[]> => {
      const rows = await sql`SELECT * FROM expenses WHERE status = ${status} ORDER BY created_at DESC`
      return Promise.all(rows.map(rowToExpense))
    },
    create: async (expense: Expense): Promise<Expense> => {
      // Insert expense
      await sql`
        INSERT INTO expenses (id, employee_id, employee_name, amount, currency, category, description, date, status, receipt_url, created_at, updated_at)
        VALUES (${expense.id}, ${expense.employeeId}, ${expense.employeeName}, ${expense.amount}, ${expense.currency}, ${expense.category}, ${expense.description}, ${expense.date}, ${expense.status}, ${expense.receiptUrl || null}, ${expense.createdAt}, ${expense.updatedAt})
      `

      // Insert approval steps
      for (let i = 0; i < expense.approvalChain.length; i++) {
        const step = expense.approvalChain[i]
        await sql`
          INSERT INTO approval_steps (expense_id, approver_id, approver_name, status, comments, timestamp, step_order)
          VALUES (${expense.id}, ${step.approverId}, ${step.approverName}, ${step.status}, ${step.comments || null}, ${step.timestamp || null}, ${i})
        `
      }

      return expense
    },
    update: async (id: string, data: Partial<Expense>): Promise<Expense | undefined> => {
      const updates: string[] = []

      if (data.amount !== undefined) updates.push(`amount = ${data.amount}`)
      if (data.category !== undefined) updates.push(`category = '${data.category}'`)
      if (data.description !== undefined) updates.push(`description = '${data.description}'`)
      if (data.status !== undefined) updates.push(`status = '${data.status}'`)
      if (data.receiptUrl !== undefined) updates.push(`receipt_url = '${data.receiptUrl}'`)

      updates.push(`updated_at = CURRENT_TIMESTAMP`)

      if (updates.length === 1) return db.expenses.findById(id)

      await sql`UPDATE expenses SET ${sql.unsafe(updates.join(", "))} WHERE id = ${id}`

      // Update approval chain if provided
      if (data.approvalChain) {
        await sql`DELETE FROM approval_steps WHERE expense_id = ${id}`
        for (let i = 0; i < data.approvalChain.length; i++) {
          const step = data.approvalChain[i]
          await sql`
            INSERT INTO approval_steps (expense_id, approver_id, approver_name, status, comments, timestamp, step_order)
            VALUES (${id}, ${step.approverId}, ${step.approverName}, ${step.status}, ${step.comments || null}, ${step.timestamp || null}, ${i})
          `
        }
      }

      return db.expenses.findById(id)
    },
    delete: async (id: string): Promise<boolean> => {
      const result = await sql`DELETE FROM expenses WHERE id = ${id}`
      return result.count > 0
    },
  },
  approvalRules: {
    findAll: async (): Promise<ApprovalRule[]> => {
      const rows = await sql`SELECT * FROM approval_rules ORDER BY priority ASC`
      return rows.map((row: any) => ({
        id: row.id,
        name: row.name,
        priority: row.priority,
        conditions: row.conditions,
        approvers: row.approvers,
        requireAllApprovals: row.require_all_approvals,
        isActive: row.is_active,
        createdAt: new Date(row.created_at),
        updatedAt: new Date(row.updated_at),
      }))
    },
    findById: async (id: string): Promise<ApprovalRule | undefined> => {
      const rows = await sql`SELECT * FROM approval_rules WHERE id = ${id}`
      if (rows.length === 0) return undefined
      const row = rows[0]
      return {
        id: row.id,
        name: row.name,
        priority: row.priority,
        conditions: row.conditions,
        approvers: row.approvers,
        requireAllApprovals: row.require_all_approvals,
        isActive: row.is_active,
        createdAt: new Date(row.created_at),
        updatedAt: new Date(row.updated_at),
      }
    },
    create: async (rule: ApprovalRule): Promise<ApprovalRule> => {
      await sql`
        INSERT INTO approval_rules (id, name, priority, conditions, approvers, require_all_approvals, is_active, created_at, updated_at)
        VALUES (${rule.id}, ${rule.name}, ${rule.priority}, ${JSON.stringify(rule.conditions)}, ${rule.approvers}, ${rule.requireAllApprovals}, ${rule.isActive}, ${rule.createdAt}, ${rule.updatedAt})
      `
      return rule
    },
    update: async (id: string, data: Partial<ApprovalRule>): Promise<ApprovalRule | undefined> => {
      const updates: string[] = []

      if (data.name !== undefined) updates.push(`name = '${data.name}'`)
      if (data.priority !== undefined) updates.push(`priority = ${data.priority}`)
      if (data.conditions !== undefined) updates.push(`conditions = '${JSON.stringify(data.conditions)}'`)
      if (data.approvers !== undefined)
        updates.push(`approvers = ARRAY[${data.approvers.map((a) => `'${a}'`).join(",")}]`)
      if (data.requireAllApprovals !== undefined) updates.push(`require_all_approvals = ${data.requireAllApprovals}`)
      if (data.isActive !== undefined) updates.push(`is_active = ${data.isActive}`)

      updates.push(`updated_at = CURRENT_TIMESTAMP`)

      if (updates.length === 1) return db.approvalRules.findById(id)

      await sql`UPDATE approval_rules SET ${sql.unsafe(updates.join(", "))} WHERE id = ${id}`
      return db.approvalRules.findById(id)
    },
    delete: async (id: string): Promise<boolean> => {
      const result = await sql`DELETE FROM approval_rules WHERE id = ${id}`
      return result.count > 0
    },
  },
  auditLogs: {
    findAll: async (): Promise<AuditLog[]> => {
      const rows = await sql`SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100`
      return rows.map((row: any) => ({
        id: row.id,
        userId: row.user_id,
        userName: row.user_name,
        action: row.action,
        entityType: row.entity_type,
        entityId: row.entity_id,
        details: row.details,
        timestamp: new Date(row.timestamp),
        ipAddress: row.ip_address,
      }))
    },
    create: async (log: AuditLog): Promise<AuditLog> => {
      await sql`
        INSERT INTO audit_logs (id, user_id, user_name, action, entity_type, entity_id, details, timestamp, ip_address)
        VALUES (${log.id}, ${log.userId}, ${log.userName}, ${log.action}, ${log.entityType}, ${log.entityId}, ${log.details}, ${log.timestamp}, ${log.ipAddress})
      `
      return log
    },
  },
  settings: {
    get: async (): Promise<Settings> => {
      const rows = await sql`SELECT * FROM settings WHERE id = 1`
      if (rows.length === 0) {
        throw new Error("Settings not found")
      }
      const row = rows[0]
      return {
        companyName: row.company_name,
        defaultCurrency: row.default_currency,
        supportedCurrencies: row.supported_currencies,
        maxExpenseAmount: Number.parseFloat(row.max_expense_amount),
        requireReceipts: row.require_receipts,
        receiptRequiredAmount: Number.parseFloat(row.receipt_required_amount),
        autoApprovalThreshold: Number.parseFloat(row.auto_approval_threshold),
        fiscalYearStart: row.fiscal_year_start,
        notificationEmail: row.notification_email,
        updatedAt: new Date(row.updated_at),
      }
    },
    update: async (data: Partial<Settings>): Promise<Settings> => {
      const updates: string[] = []

      if (data.companyName !== undefined) updates.push(`company_name = '${data.companyName}'`)
      if (data.defaultCurrency !== undefined) updates.push(`default_currency = '${data.defaultCurrency}'`)
      if (data.supportedCurrencies !== undefined)
        updates.push(`supported_currencies = ARRAY[${data.supportedCurrencies.map((c) => `'${c}'`).join(",")}]`)
      if (data.maxExpenseAmount !== undefined) updates.push(`max_expense_amount = ${data.maxExpenseAmount}`)
      if (data.requireReceipts !== undefined) updates.push(`require_receipts = ${data.requireReceipts}`)
      if (data.receiptRequiredAmount !== undefined)
        updates.push(`receipt_required_amount = ${data.receiptRequiredAmount}`)
      if (data.autoApprovalThreshold !== undefined)
        updates.push(`auto_approval_threshold = ${data.autoApprovalThreshold}`)
      if (data.fiscalYearStart !== undefined) updates.push(`fiscal_year_start = '${data.fiscalYearStart}'`)
      if (data.notificationEmail !== undefined) updates.push(`notification_email = '${data.notificationEmail}'`)

      updates.push(`updated_at = CURRENT_TIMESTAMP`)

      if (updates.length > 1) {
        await sql`UPDATE settings SET ${sql.unsafe(updates.join(", "))} WHERE id = 1`
      }

      return db.settings.get()
    },
  },
}

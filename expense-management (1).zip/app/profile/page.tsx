"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ArrowLeft, Camera, Save } from "lucide-react"
import { AdminLayout } from "@/components/admin-layout"
import { EmployeeLayout } from "@/components/employee-layout"
import { ManagerLayout } from "@/components/manager-layout"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function ProfilePage() {
  const { user, updateProfile } = useAuth()
  const router = useRouter()
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    phone: user?.phone || "",
    department: user?.department || "",
    profilePhoto: user?.profilePhoto || "",
  })

  const [countryCode, setCountryCode] = useState("+1")
  const [phoneNumber, setPhoneNumber] = useState("")

  const [previewImage, setPreviewImage] = useState(user?.profilePhoto || "")

  const [errors, setErrors] = useState({
    email: "",
    phone: "",
  })

  useEffect(() => {
    if (user?.phone) {
      // Extract country code and phone number from stored format
      const phoneStr = user.phone.toString()
      const countryCodes = ["+1", "+44", "+91", "+86", "+81", "+49", "+33", "+61", "+55", "+52"]

      let extractedCode = "+1"
      let extractedNumber = ""

      // Find matching country code
      for (const code of countryCodes) {
        if (phoneStr.startsWith(code)) {
          extractedCode = code
          extractedNumber = phoneStr.slice(code.length)
          break
        }
      }

      // If no country code found, assume it's just digits
      if (!extractedNumber) {
        extractedNumber = phoneStr.replace(/\D/g, "")
      }

      setCountryCode(extractedCode)
      setPhoneNumber(formatPhoneNumber(extractedNumber))
    }
  }, [user?.phone])

  const validateEmail = (email: string): boolean => {
    if (!email || email.trim() === "") return false

    // No spaces allowed
    if (/\s/.test(email)) return false

    // Must have exactly one @
    const atCount = (email.match(/@/g) || []).length
    if (atCount !== 1) return false

    const [username, domain] = email.split("@")

    // Username validation
    if (!username || username.length === 0) return false
    // Must not start or end with dot
    if (username.startsWith(".") || username.endsWith(".")) return false
    // Can only contain letters, digits, dots, underscores, hyphens
    if (!/^[a-zA-Z0-9._-]+$/.test(username)) return false

    // Domain validation
    if (!domain || domain.length === 0) return false
    // Must contain at least one dot
    if (!domain.includes(".")) return false

    const domainParts = domain.split(".")
    // Each domain part must start and end with letter/digit
    for (const part of domainParts) {
      if (!part || part.length === 0) return false
      if (!/^[a-zA-Z0-9]/.test(part) || !/[a-zA-Z0-9]$/.test(part)) return false
      if (!/^[a-zA-Z0-9-]+$/.test(part)) return false
    }

    // TLD must be at least 2 characters
    const tld = domainParts[domainParts.length - 1]
    if (tld.length < 2) return false

    return true
  }

  const validatePhone = (phone: string): boolean => {
    if (!phone || phone.trim() === "") return false
    const cleanPhone = phone.replace(/\D/g, "")
    return cleanPhone.length === 10
  }

  const formatPhoneNumber = (value: string): string => {
    const cleaned = value.replace(/\D/g, "")
    const limited = cleaned.slice(0, 10)

    if (limited.length <= 3) {
      return limited
    } else if (limited.length <= 6) {
      return `(${limited.slice(0, 3)}) ${limited.slice(3)}`
    } else {
      return `(${limited.slice(0, 3)}) ${limited.slice(3, 6)}-${limited.slice(6)}`
    }
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        const result = reader.result as string
        setPreviewImage(result)
        setFormData({ ...formData, profilePhoto: result })
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newErrors = { email: "", phone: "" }
    let hasError = false

    if (!formData.email || formData.email.trim() === "") {
      newErrors.email = "Email is required"
      hasError = true
    } else if (!validateEmail(formData.email)) {
      newErrors.email = "Invalid email. Must be username@domain.tld (no spaces, valid characters only)"
      hasError = true
    }

    const cleanPhone = phoneNumber.replace(/\D/g, "")
    if (!phoneNumber || phoneNumber.trim() === "") {
      newErrors.phone = "Phone number is required"
      hasError = true
    } else if (cleanPhone.length !== 10) {
      newErrors.phone = `Phone must be exactly 10 digits (currently ${cleanPhone.length} digits)`
      hasError = true
    }

    if (!formData.name || formData.name.trim() === "") {
      alert("Name is required")
      return
    }

    setErrors(newErrors)

    if (hasError) {
      alert("Please fix all validation errors before saving")
      return
    }

    const fullPhone = `${countryCode}${cleanPhone}`

    updateProfile({ ...formData, phone: fullPhone })
    alert("Profile updated successfully!")
  }

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newEmail = e.target.value
    setFormData({ ...formData, email: newEmail })

    if (newEmail && !validateEmail(newEmail)) {
      setErrors({ ...errors, email: "Invalid email format" })
    } else if (!newEmail) {
      setErrors({ ...errors, email: "Email is required" })
    } else {
      setErrors({ ...errors, email: "" })
    }
  }

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhoneNumber(e.target.value)
    setPhoneNumber(formatted)

    const cleanPhone = formatted.replace(/\D/g, "")

    if (formatted && cleanPhone.length !== 10 && cleanPhone.length > 0) {
      setErrors({ ...errors, phone: `Phone must be exactly 10 digits (currently ${cleanPhone.length} digits)` })
    } else if (!formatted) {
      setErrors({ ...errors, phone: "Phone number is required" })
    } else if (cleanPhone.length === 10) {
      setErrors({ ...errors, phone: "" })
    }
  }

  const handleEmailBlur = () => {
    if (!formData.email || formData.email.trim() === "") {
      setErrors({ ...errors, email: "Email is required" })
    } else if (!validateEmail(formData.email)) {
      setErrors({ ...errors, email: "Invalid email. Check username, @, domain, and TLD format" })
    } else {
      setErrors({ ...errors, email: "" })
    }
  }

  const handlePhoneBlur = () => {
    const cleanPhone = phoneNumber.replace(/\D/g, "")
    if (!phoneNumber || phoneNumber.trim() === "") {
      setErrors({ ...errors, phone: "Phone number is required" })
    } else if (cleanPhone.length !== 10) {
      setErrors({ ...errors, phone: `Phone must be exactly 10 digits (currently ${cleanPhone.length} digits)` })
    } else {
      setErrors({ ...errors, phone: "" })
    }
  }

  const handleBack = () => {
    if (user?.role === "admin") router.push("/admin")
    else if (user?.role === "manager") router.push("/manager")
    else router.push("/employee")
  }

  const content = (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={handleBack}
          className="transition-all duration-200 hover:scale-110"
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold">Profile Settings</h1>
          <p className="text-muted-foreground">Manage your account information</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3 animate-stagger">
        <Card className="md:col-span-1 transition-all duration-300 hover:shadow-lg hover:scale-[1.02]">
          <CardHeader>
            <CardTitle>Profile Photo</CardTitle>
            <CardDescription>Upload your profile picture</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center gap-4">
            <div className="relative group">
              <Avatar className="h-32 w-32 border-4 border-primary/20 transition-all duration-300 group-hover:border-primary/40 group-hover:scale-105">
                <AvatarImage src={previewImage || "/placeholder.svg"} alt={formData.name} />
                <AvatarFallback className="bg-primary/10 text-primary text-3xl font-bold">
                  {formData.name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-0 right-0 p-2 bg-primary text-primary-foreground rounded-full shadow-lg transition-all duration-200 hover:scale-110 hover:shadow-xl hover:rotate-12"
              >
                <Camera className="h-4 w-4" />
              </button>
            </div>
            <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
            <p className="text-xs text-muted-foreground text-center">Click the camera icon to upload a new photo</p>
          </CardContent>
        </Card>

        <Card className="md:col-span-2 transition-all duration-300 hover:shadow-lg">
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
            <CardDescription>Update your personal details</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="transition-all duration-200 focus:scale-[1.01]"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={handleEmailChange}
                    onBlur={handleEmailBlur}
                    required
                    placeholder="user@example.com"
                    className={`transition-all duration-200 focus:scale-[1.01] ${
                      errors.email
                        ? "border-red-500 focus-visible:ring-red-500"
                        : formData.email && validateEmail(formData.email)
                          ? "border-green-500 focus-visible:ring-green-500"
                          : ""
                    }`}
                  />
                  {errors.email && <p className="text-sm text-red-500 font-medium animate-fade-in">{errors.email}</p>}
                  {!errors.email && formData.email && validateEmail(formData.email) && (
                    <p className="text-sm text-green-600 font-medium animate-fade-in">✓ Valid email format</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number (10 digits) *</Label>
                  <div className="flex gap-2">
                    <Select value={countryCode} onValueChange={setCountryCode}>
                      <SelectTrigger className="w-[120px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="+1">🇺🇸 +1</SelectItem>
                        <SelectItem value="+44">🇬🇧 +44</SelectItem>
                        <SelectItem value="+91">🇮🇳 +91</SelectItem>
                        <SelectItem value="+86">🇨🇳 +86</SelectItem>
                        <SelectItem value="+81">🇯🇵 +81</SelectItem>
                        <SelectItem value="+49">🇩🇪 +49</SelectItem>
                        <SelectItem value="+33">🇫🇷 +33</SelectItem>
                        <SelectItem value="+61">🇦🇺 +61</SelectItem>
                        <SelectItem value="+55">🇧🇷 +55</SelectItem>
                        <SelectItem value="+52">🇲🇽 +52</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      id="phone"
                      type="tel"
                      value={phoneNumber}
                      onChange={handlePhoneChange}
                      onBlur={handlePhoneBlur}
                      required
                      placeholder="(123) 456-7890"
                      maxLength={14}
                      className={`flex-1 transition-all duration-200 focus:scale-[1.01] ${
                        errors.phone
                          ? "border-red-500 focus-visible:ring-red-500"
                          : phoneNumber && validatePhone(phoneNumber)
                            ? "border-green-500 focus-visible:ring-green-500"
                            : ""
                      }`}
                    />
                  </div>
                  {errors.phone && <p className="text-sm text-red-500 font-medium animate-fade-in">{errors.phone}</p>}
                  {!errors.phone && phoneNumber && validatePhone(phoneNumber) && (
                    <p className="text-sm text-green-600 font-medium animate-fade-in">✓ Valid 10-digit number</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="department">Department</Label>
                  <Input
                    id="department"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    disabled={user?.role === "employee"}
                    className="transition-all duration-200 focus:scale-[1.01]"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="role">Role</Label>
                  <Input id="role" value={user?.role} disabled className="capitalize" />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleBack}
                  className="transition-all duration-200 hover:scale-105 bg-transparent"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="transition-all duration-200 hover:scale-105 hover:shadow-lg"
                  disabled={!!errors.email || !!errors.phone || !formData.email || !phoneNumber || !formData.name}
                >
                  <Save className="mr-2 h-4 w-4" />
                  Save Changes
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  if (user?.role === "admin") {
    return <AdminLayout currentPage="/profile">{content}</AdminLayout>
  } else if (user?.role === "manager") {
    return <ManagerLayout currentPage="/profile">{content}</ManagerLayout>
  } else {
    return <EmployeeLayout currentPage="/profile">{content}</EmployeeLayout>
  }
}

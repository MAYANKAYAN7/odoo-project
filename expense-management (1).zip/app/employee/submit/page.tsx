"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useExpenses } from "@/lib/expenses-context"
import { EmployeeLayout } from "@/components/employee-layout"
import type { ExpenseCategory } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, CheckCircle } from "lucide-react"
import { mockUsers } from "@/lib/mock-data"

export default function SubmitExpensePage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()
  const { addExpense } = useExpenses()
  const [formData, setFormData] = useState({
    amount: "",
    currency: "USD",
    category: "" as ExpenseCategory | "",
    description: "",
    date: new Date().toISOString().split("T")[0],
    managerId: "",
  })
  const [receiptFile, setReceiptFile] = useState<File | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [success, setSuccess] = useState(false)

  const managers = mockUsers.filter((u) => u.role === "manager")

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "employee")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    if (user?.managerId) {
      setFormData((prev) => ({ ...prev, managerId: user.managerId! }))
    }
  }, [user])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setReceiptFile(e.target.files[0])
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    const selectedManagerId = formData.managerId || user!.managerId
    const selectedManager = mockUsers.find((u) => u.id === selectedManagerId)

    const newExpense = {
      employeeId: user!.id,
      employeeName: user!.name,
      amount: Number.parseFloat(formData.amount),
      currency: formData.currency,
      category: formData.category as ExpenseCategory,
      description: formData.description,
      date: new Date(formData.date),
      status: "pending" as const,
      approvalChain: selectedManagerId
        ? [
            {
              approverId: selectedManagerId,
              approverName: selectedManager?.name || "Manager",
              status: "pending" as const,
            },
          ]
        : [],
    }

    addExpense(newExpense)

    // Simulate submission delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    setSuccess(true)
    setIsSubmitting(false)

    // Reset form after 2 seconds
    setTimeout(() => {
      setFormData({
        amount: "",
        currency: "USD",
        category: "",
        description: "",
        date: new Date().toISOString().split("T")[0],
        managerId: user?.managerId || "",
      })
      setReceiptFile(null)
      setSuccess(false)
    }, 2000)
  }

  if (isLoading || !user) {
    return null
  }

  return (
    <EmployeeLayout currentPage="/employee/submit">
      <div className="max-w-2xl">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Submit Expense</h1>
          <p className="text-muted-foreground mt-1">Create a new expense report</p>
        </div>

        {success && (
          <Alert className="mb-6 border-success bg-success/10">
            <CheckCircle className="h-4 w-4 text-success" />
            <AlertDescription className="text-success">Expense submitted successfully!</AlertDescription>
          </Alert>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Expense Details</CardTitle>
            <CardDescription>Fill in the information about your expense</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="manager">Approving Manager *</Label>
                <Select
                  value={formData.managerId}
                  onValueChange={(value) => setFormData({ ...formData, managerId: value })}
                  required
                >
                  <SelectTrigger id="manager">
                    <SelectValue placeholder="Select a manager" />
                  </SelectTrigger>
                  <SelectContent>
                    {managers.map((manager) => (
                      <SelectItem key={manager.id} value={manager.id}>
                        {manager.name} - {manager.department}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount *</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    placeholder="0.00"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="currency">Currency *</Label>
                  <Select
                    value={formData.currency}
                    onValueChange={(value) => setFormData({ ...formData, currency: value })}
                  >
                    <SelectTrigger id="currency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD</SelectItem>
                      <SelectItem value="EUR">EUR</SelectItem>
                      <SelectItem value="GBP">GBP</SelectItem>
                      <SelectItem value="JPY">JPY</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Category *</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value as ExpenseCategory })}
                >
                  <SelectTrigger id="category">
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="travel">Travel</SelectItem>
                    <SelectItem value="meals">Meals</SelectItem>
                    <SelectItem value="accommodation">Accommodation</SelectItem>
                    <SelectItem value="transportation">Transportation</SelectItem>
                    <SelectItem value="office_supplies">Office Supplies</SelectItem>
                    <SelectItem value="software">Software</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="date">Date *</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Provide details about this expense..."
                  rows={4}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="receipt">Receipt</Label>
                <div className="flex items-center gap-4">
                  <Input
                    id="receipt"
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleFileChange}
                    className="flex-1"
                  />
                  {receiptFile && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Upload className="h-4 w-4" />
                      {receiptFile.name}
                    </div>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">Upload a photo or PDF of your receipt</p>
              </div>

              <div className="flex gap-4">
                <Button type="submit" disabled={isSubmitting} className="flex-1">
                  {isSubmitting ? "Submitting..." : "Submit Expense"}
                </Button>
                <Button type="button" variant="outline" onClick={() => router.push("/employee")}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </EmployeeLayout>
  )
}

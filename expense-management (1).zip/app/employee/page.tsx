"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useExpenses } from "@/lib/expenses-context"
import { EmployeeLayout } from "@/components/employee-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { FileText, DollarSign, Clock, CheckCircle, Plus, XCircle } from "lucide-react"
import Link from "next/link"

export default function EmployeeDashboard() {
  const router = useRouter()
  const { user, isLoading } = useAuth()
  const { expenses: allExpenses } = useExpenses()

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "employee")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return null
  }

  const myExpenses = allExpenses.filter((e) => e.employeeId === user.id)
  const pendingExpenses = myExpenses.filter((e) => e.status === "pending")
  const approvedExpenses = myExpenses.filter((e) => e.status === "approved")
  const rejectedExpenses = myExpenses.filter((e) => e.status === "rejected")
  const totalAmount = myExpenses.reduce((sum, e) => sum + e.amount, 0)

  const stats = [
    {
      title: "Total Expenses",
      value: myExpenses.length,
      icon: FileText,
      description: "All time",
    },
    {
      title: "Pending",
      value: pendingExpenses.length,
      icon: Clock,
      description: "Awaiting approval",
    },
    {
      title: "Approved",
      value: approvedExpenses.length,
      icon: CheckCircle,
      description: "Approved expenses",
    },
    {
      title: "Rejected",
      value: rejectedExpenses.length,
      icon: XCircle,
      description: "Rejected expenses",
    },
    {
      title: "Total Amount",
      value: `$${totalAmount.toLocaleString()}`,
      icon: DollarSign,
      description: "All expenses",
    },
  ]

  return (
    <EmployeeLayout currentPage="/employee">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground mt-1">Welcome back, {user.name}</p>
          </div>
          <Link href="/employee/submit">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Submit Expense
            </Button>
          </Link>
        </div>

        <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-5">
          {stats.map((stat) => {
            const Icon = stat.icon
            return (
              <Card key={stat.title}>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
                  <Icon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <p className="text-xs text-muted-foreground mt-1">{stat.description}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Recent Expenses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {myExpenses.slice(0, 5).map((expense) => (
                <div
                  key={expense.id}
                  className="flex items-center justify-between border-b border-border pb-4 last:border-0 last:pb-0"
                >
                  <div className="space-y-1">
                    <p className="text-sm font-medium">{expense.description}</p>
                    <div className="flex items-center gap-2">
                      <p className="text-xs text-muted-foreground">
                        {expense.date.toLocaleDateString()} • {expense.category}
                      </p>
                      <Badge
                        variant={
                          expense.status === "approved"
                            ? "default"
                            : expense.status === "rejected"
                              ? "destructive"
                              : "secondary"
                        }
                      >
                        {expense.status}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">
                      ${expense.amount.toFixed(2)} {expense.currency}
                    </p>
                  </div>
                </div>
              ))}
              {myExpenses.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No expenses yet</p>
                  <Link href="/employee/submit">
                    <Button variant="link" className="mt-2">
                      Submit your first expense
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </EmployeeLayout>
  )
}

"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useExpenses } from "@/lib/expenses-context"
import { AdminLayout } from "@/components/admin-layout"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, FileText, DollarSign, Calendar, ShieldAlert } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import type { Expense, ExpenseStatus } from "@/lib/types"

export default function AdminExpensesPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()
  const { expenses, updateExpense } = useExpenses()
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [overrideDialogOpen, setOverrideDialogOpen] = useState(false)
  const [selectedExpense, setSelectedExpense] = useState<Expense | null>(null)
  const [overrideStatus, setOverrideStatus] = useState<ExpenseStatus>("approved")
  const [overrideComments, setOverrideComments] = useState("")

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "admin")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return null
  }

  const filteredExpenses = expenses.filter((expense) => {
    const matchesSearch =
      expense.employeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      expense.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      expense.category.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || expense.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "default"
      case "rejected":
        return "destructive"
      case "pending":
        return "secondary"
      default:
        return "secondary"
    }
  }

  const handleOpenOverride = (expense: Expense) => {
    setSelectedExpense(expense)
    setOverrideStatus(expense.status)
    setOverrideComments("")
    setOverrideDialogOpen(true)
  }

  const handleOverrideSubmit = () => {
    if (!selectedExpense || !user) return

    // Update the expense with new status and add admin override to approval chain
    const updatedApprovalChain = [
      ...selectedExpense.approvalChain,
      {
        approverId: user.id,
        approverName: user.name,
        status: overrideStatus === "approved" ? "approved" : overrideStatus === "rejected" ? "rejected" : "pending",
        comments: `[ADMIN OVERRIDE] ${overrideComments}`,
        timestamp: new Date(),
      },
    ]

    updateExpense(selectedExpense.id, {
      status: overrideStatus,
      approvalChain: updatedApprovalChain,
    })

    toast({
      title: "Override Applied",
      description: `Expense status changed to ${overrideStatus}`,
    })

    setOverrideDialogOpen(false)
    setSelectedExpense(null)
    setOverrideComments("")
  }

  const hasAdminOverride = (expense: Expense) => {
    return expense.approvalChain.some((step) => step.comments?.includes("[ADMIN OVERRIDE]"))
  }

  const totalAmount = filteredExpenses.reduce((sum, e) => sum + e.amount, 0)
  const pendingCount = filteredExpenses.filter((e) => e.status === "pending").length
  const approvedCount = filteredExpenses.filter((e) => e.status === "approved").length

  return (
    <AdminLayout currentPage="/admin/expenses">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">All Expenses</h1>
          <p className="text-muted-foreground mt-1">View and monitor all expense requests across the organization</p>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Amount</p>
                  <p className="text-2xl font-bold">${totalAmount.toLocaleString()}</p>
                </div>
                <DollarSign className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Pending</p>
                  <p className="text-2xl font-bold">{pendingCount}</p>
                </div>
                <FileText className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Approved</p>
                  <p className="text-2xl font-bold">{approvedCount}</p>
                </div>
                <Calendar className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search expenses..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          {filteredExpenses
            .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
            .map((expense) => (
              <Card key={expense.id}>
                <CardContent className="py-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-2">
                        <Badge variant={getStatusColor(expense.status)}>{expense.status}</Badge>
                        <span className="text-sm font-medium">{expense.category}</span>
                        {hasAdminOverride(expense) && (
                          <Badge variant="outline" className="gap-1">
                            <ShieldAlert className="h-3 w-3" />
                            Admin Override
                          </Badge>
                        )}
                      </div>
                      <p className="font-medium">{expense.description}</p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>Employee: {expense.employeeName}</span>
                        <span>•</span>
                        <span>Amount: ${expense.amount.toFixed(2)}</span>
                        <span>•</span>
                        <span>Date: {new Date(expense.date).toLocaleDateString()}</span>
                      </div>
                      {expense.approvalChain.length > 0 && (
                        <div className="mt-2 space-y-1">
                          <p className="text-xs font-medium text-muted-foreground">Approval History:</p>
                          {expense.approvalChain.map((step, index) => (
                            <div key={index} className="text-xs text-muted-foreground pl-2">
                              <span className="font-medium">{step.approverName}</span>
                              {" - "}
                              <span
                                className={
                                  step.status === "approved"
                                    ? "text-green-600"
                                    : step.status === "rejected"
                                      ? "text-red-600"
                                      : "text-yellow-600"
                                }
                              >
                                {step.status}
                              </span>
                              {step.timestamp && ` on ${new Date(step.timestamp).toLocaleDateString()}`}
                              {step.comments && <span className="block pl-4 italic">{step.comments}</span>}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <p className="text-xl font-bold">${expense.amount.toFixed(2)}</p>
                      <Button variant="outline" size="sm" onClick={() => handleOpenOverride(expense)} className="gap-2">
                        <ShieldAlert className="h-4 w-4" />
                        Override
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          {filteredExpenses.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground">No expenses found</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <Dialog open={overrideDialogOpen} onOpenChange={setOverrideDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-destructive" />
              Admin Override - Special Case
            </DialogTitle>
            <DialogDescription>
              Override the approval decision for this expense. This action will be logged and marked as an admin
              override.
            </DialogDescription>
          </DialogHeader>
          {selectedExpense && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <p className="text-sm font-medium">Expense Details:</p>
                <div className="text-sm text-muted-foreground space-y-1 bg-muted p-3 rounded-lg">
                  <p>
                    <span className="font-medium">Description:</span> {selectedExpense.description}
                  </p>
                  <p>
                    <span className="font-medium">Employee:</span> {selectedExpense.employeeName}
                  </p>
                  <p>
                    <span className="font-medium">Amount:</span> ${selectedExpense.amount.toFixed(2)}{" "}
                    {selectedExpense.currency}
                  </p>
                  <p>
                    <span className="font-medium">Current Status:</span>{" "}
                    <Badge variant={getStatusColor(selectedExpense.status)}>{selectedExpense.status}</Badge>
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="override-status">New Status</Label>
                <Select value={overrideStatus} onValueChange={(value) => setOverrideStatus(value as ExpenseStatus)}>
                  <SelectTrigger id="override-status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="override-comments">
                  Comments <span className="text-destructive">*</span>
                </Label>
                <Textarea
                  id="override-comments"
                  placeholder="Explain the reason for this override (required)..."
                  value={overrideComments}
                  onChange={(e) => setOverrideComments(e.target.value)}
                  rows={4}
                  className="resize-none"
                />
                <p className="text-xs text-muted-foreground">
                  This comment will be marked as an admin override and included in the approval history.
                </p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setOverrideDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleOverrideSubmit}
              disabled={!overrideComments.trim()}
              className="bg-destructive hover:bg-destructive/90"
            >
              Apply Override
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  )
}

"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { AdminLayout } from "@/components/admin-layout"
import type { User } from "@/lib/types"
import { mockUsers } from "@/lib/mock-data"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Pencil, Trash2 } from "lucide-react"

export default function ManagersPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()
  const [managers, setManagers] = useState<User[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingManager, setEditingManager] = useState<User | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    department: "",
  })

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "admin")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    setManagers(mockUsers.filter((u) => u.role === "manager"))
  }, [])

  const handleOpenDialog = (manager?: User) => {
    if (manager) {
      setEditingManager(manager)
      setFormData({
        name: manager.name,
        email: manager.email,
        department: manager.department || "",
      })
    } else {
      setEditingManager(null)
      setFormData({ name: "", email: "", department: "" })
    }
    setIsDialogOpen(true)
  }

  const handleSave = () => {
    if (editingManager) {
      // Update existing manager
      setManagers(
        managers.map((mgr) => (mgr.id === editingManager.id ? { ...mgr, ...formData, updatedAt: new Date() } : mgr)),
      )
    } else {
      // Add new manager
      const newManager: User = {
        id: Date.now().toString(),
        ...formData,
        role: "manager",
        createdAt: new Date(),
        updatedAt: new Date(),
      }
      setManagers([...managers, newManager])
    }
    setIsDialogOpen(false)
  }

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this manager?")) {
      setManagers(managers.filter((mgr) => mgr.id !== id))
    }
  }

  if (isLoading || !user) {
    return null
  }

  const getEmployeeCount = (managerId: string) => {
    return mockUsers.filter((u) => u.role === "employee" && u.managerId === managerId).length
  }

  return (
    <AdminLayout currentPage="/admin/managers">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Managers</h1>
            <p className="text-muted-foreground mt-1">Manage manager accounts</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => handleOpenDialog()}>
                <Plus className="mr-2 h-4 w-4" />
                Add Manager
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{editingManager ? "Edit Manager" : "Add Manager"}</DialogTitle>
                <DialogDescription>
                  {editingManager ? "Update manager information" : "Create a new manager account"}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Jane Smith"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="jane@company.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="department">Department</Label>
                  <Input
                    id="department"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    placeholder="Engineering"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSave}>Save</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="rounded-lg border border-border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Employees</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {managers.map((manager) => (
                <TableRow key={manager.id}>
                  <TableCell className="font-medium">{manager.name}</TableCell>
                  <TableCell>{manager.email}</TableCell>
                  <TableCell>{manager.department || "-"}</TableCell>
                  <TableCell>{getEmployeeCount(manager.id)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="sm" onClick={() => handleOpenDialog(manager)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => handleDelete(manager.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </AdminLayout>
  )
}

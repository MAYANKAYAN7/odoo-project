"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useExpenses } from "@/lib/expenses-context"
import { AdminLayout } from "@/components/admin-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, UserCog, FileText, DollarSign, XCircle, CheckCircle } from "lucide-react"
import { mockUsers } from "@/lib/mock-data"

export default function AdminDashboard() {
  const router = useRouter()
  const { user, isLoading } = useAuth()
  const { expenses } = useExpenses()

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "admin")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return null
  }

  const employees = mockUsers.filter((u) => u.role === "employee")
  const managers = mockUsers.filter((u) => u.role === "manager")
  const pendingExpenses = expenses.filter((e) => e.status === "pending")
  const approvedExpenses = expenses.filter((e) => e.status === "approved")
  const rejectedExpenses = expenses.filter((e) => e.status === "rejected")
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0)

  const stats = [
    {
      title: "Total Employees",
      value: employees.length,
      icon: Users,
      description: "Active employees",
    },
    {
      title: "Total Managers",
      value: managers.length,
      icon: UserCog,
      description: "Active managers",
    },
    {
      title: "Pending Expenses",
      value: pendingExpenses.length,
      icon: FileText,
      description: "Awaiting approval",
    },
    {
      title: "Approved",
      value: approvedExpenses.length,
      icon: CheckCircle,
      description: "Approved expenses",
    },
    {
      title: "Rejected",
      value: rejectedExpenses.length,
      icon: XCircle,
      description: "Rejected expenses",
    },
    {
      title: "Total Expenses",
      value: `$${totalExpenses.toLocaleString()}`,
      icon: DollarSign,
      description: "All time",
    },
  ]

  return (
    <AdminLayout currentPage="/admin">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Overview of your expense management system</p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {stats.map((stat) => {
            const Icon = stat.icon
            return (
              <Card key={stat.title}>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
                  <Icon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <p className="text-xs text-muted-foreground mt-1">{stat.description}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {expenses
                  .sort((a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime())
                  .slice(0, 5)
                  .map((expense) => (
                    <div key={expense.id} className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium">{expense.employeeName}</p>
                        <p className="text-xs text-muted-foreground">{expense.description}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">${expense.amount.toFixed(2)}</p>
                        <p
                          className={`text-xs ${
                            expense.status === "approved"
                              ? "text-green-600"
                              : expense.status === "rejected"
                                ? "text-red-600"
                                : "text-yellow-600"
                          }`}
                        >
                          {expense.status}
                        </p>
                      </div>
                    </div>
                  ))}
                {expenses.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">No expenses yet</p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <a
                  href="/admin/expenses"
                  className="block rounded-lg border border-border p-3 hover:bg-accent transition-colors"
                >
                  <p className="font-medium text-sm">View All Expenses</p>
                  <p className="text-xs text-muted-foreground">See all expense requests</p>
                </a>
                <a
                  href="/admin/employees"
                  className="block rounded-lg border border-border p-3 hover:bg-accent transition-colors"
                >
                  <p className="font-medium text-sm">Manage Employees</p>
                  <p className="text-xs text-muted-foreground">Add, edit, or remove employees</p>
                </a>
                <a
                  href="/admin/managers"
                  className="block rounded-lg border border-border p-3 hover:bg-accent transition-colors"
                >
                  <p className="font-medium text-sm">Manage Managers</p>
                  <p className="text-xs text-muted-foreground">Add, edit, or remove managers</p>
                </a>
                <a
                  href="/admin/approval-rules"
                  className="block rounded-lg border border-border p-3 hover:bg-accent transition-colors"
                >
                  <p className="font-medium text-sm">Configure Approval Rules</p>
                  <p className="text-xs text-muted-foreground">Set up expense approval workflows</p>
                </a>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  )
}

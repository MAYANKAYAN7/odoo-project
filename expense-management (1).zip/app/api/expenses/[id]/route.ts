import { NextResponse } from "next/server"
import { getExpenseById } from "@/lib/actions/expenses"

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const expense = await getExpenseById(id)

    if (!expense) {
      return NextResponse.json({ error: "Expense not found" }, { status: 404 })
    }

    return NextResponse.json({ expense })
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to fetch expense" },
      { status: 401 },
    )
  }
}

import { NextResponse } from "next/server"
import { getExpenses } from "@/lib/actions/expenses"

export async function GET() {
  try {
    const expenses = await getExpenses()
    return NextResponse.json({ expenses })
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to fetch expenses" },
      { status: 401 },
    )
  }
}

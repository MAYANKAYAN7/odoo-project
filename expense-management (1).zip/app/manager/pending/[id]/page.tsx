"use client"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useExpenses } from "@/lib/expenses-context"
import { ManagerLayout } from "@/components/manager-layout"
import type { Expense } from "@/lib/types"
import { mockUsers } from "@/lib/mock-data"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle, XCircle, ArrowLeft, FileText } from "lucide-react"

export default function ExpenseDetailPage() {
  const router = useRouter()
  const params = useParams()
  const { user, isLoading } = useAuth()
  const { expenses: allExpenses, updateExpense } = useExpenses()
  const [expense, setExpense] = useState<Expense | null>(null)
  const [comments, setComments] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [actionResult, setActionResult] = useState<{ type: "success" | "error"; message: string } | null>(null)

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "manager")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    if (params.id) {
      const found = allExpenses.find((e) => e.id === params.id)
      if (found) {
        setExpense(found)
      }
    }
  }, [params.id, allExpenses])

  const handleApprove = async () => {
    if (!expense || !user) return

    setIsSubmitting(true)
    setActionResult(null)

    console.log("[v0] Approving expense:", expense.id)
    await new Promise((resolve) => setTimeout(resolve, 500))

    const updatedApprovalChain = expense.approvalChain.map((step) =>
      step.approverId === user.id ? { ...step, status: "approved" as const, comments, timestamp: new Date() } : step,
    )

    const allApproved = updatedApprovalChain.every((step) => step.status === "approved")

    updateExpense(expense.id, {
      approvalChain: updatedApprovalChain,
      status: allApproved ? "approved" : "pending",
    })

    setActionResult({ type: "success", message: "Expense approved successfully" })
    setIsSubmitting(false)
    setTimeout(() => router.push("/manager/pending"), 2000)
  }

  const handleReject = async () => {
    setActionResult(null)

    if (!expense || !user) {
      console.log("[v0] Reject failed: Missing expense or user")
      setActionResult({ type: "error", message: "Unable to process rejection. Please try again." })
      return
    }

    if (!comments.trim()) {
      console.log("[v0] Reject failed: No comments provided")
      setActionResult({ type: "error", message: "Please provide a reason for rejection" })
      return
    }

    setIsSubmitting(true)
    console.log("[v0] Rejecting expense:", expense.id, "with comments:", comments)

    await new Promise((resolve) => setTimeout(resolve, 500))

    const updatedApprovalChain = expense.approvalChain.map((step) =>
      step.approverId === user.id ? { ...step, status: "rejected" as const, comments, timestamp: new Date() } : step,
    )

    console.log("[v0] Updated approval chain:", updatedApprovalChain)

    updateExpense(expense.id, {
      approvalChain: updatedApprovalChain,
      status: "rejected",
    })

    console.log("[v0] Expense rejected successfully")
    setActionResult({ type: "success", message: "Expense rejected successfully" })
    setIsSubmitting(false)
    setTimeout(() => router.push("/manager/pending"), 2000)
  }

  if (isLoading || !user || !expense) {
    return null
  }

  const employee = mockUsers.find((u) => u.id === expense.employeeId)

  return (
    <ManagerLayout currentPage="/manager/pending">
      <div className="max-w-4xl space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => router.back()}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold">Expense Review</h1>
            <p className="text-muted-foreground mt-1">Review and approve or reject this expense</p>
          </div>
        </div>

        {actionResult && (
          <Alert variant={actionResult.type === "error" ? "destructive" : "default"}>
            {actionResult.type === "success" ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
            <AlertDescription>{actionResult.message}</AlertDescription>
          </Alert>
        )}

        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <CardTitle className="text-2xl">{expense.description}</CardTitle>
                <CardDescription>Submitted by {employee?.name}</CardDescription>
              </div>
              <Badge variant="secondary">Pending Review</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Amount</p>
                  <p className="text-2xl font-bold">
                    ${expense.amount.toFixed(2)} {expense.currency}
                  </p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Category</p>
                  <p className="text-base">{expense.category}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Date</p>
                  <p className="text-base">{expense.date.toLocaleDateString()}</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Employee</p>
                  <p className="text-base">{employee?.name}</p>
                  <p className="text-sm text-muted-foreground">{employee?.email}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Department</p>
                  <p className="text-base">{employee?.department || "N/A"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Submitted</p>
                  <p className="text-base">{expense.createdAt.toLocaleDateString()}</p>
                </div>
              </div>
            </div>

            <div>
              <p className="text-sm font-medium text-muted-foreground mb-2">Receipt</p>
              {expense.receiptUrl ? (
                <div className="flex items-center gap-2 text-sm">
                  <FileText className="h-4 w-4" />
                  <a href={expense.receiptUrl} target="_blank" rel="noopener noreferrer" className="text-primary">
                    View Receipt
                  </a>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No receipt attached</p>
              )}
            </div>

            <div>
              <p className="text-sm font-medium text-muted-foreground mb-2">Approval Chain</p>
              <div className="space-y-2">
                {expense.approvalChain.map((step, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div>
                      <p className="text-sm font-medium">{step.approverName}</p>
                      {step.comments && <p className="text-xs text-muted-foreground mt-1">{step.comments}</p>}
                    </div>
                    <Badge
                      variant={
                        step.status === "approved"
                          ? "default"
                          : step.status === "rejected"
                            ? "destructive"
                            : "secondary"
                      }
                    >
                      {step.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Your Decision</CardTitle>
            <CardDescription>Approve or reject this expense with optional comments</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="comments">
                Comments
                <span className="text-muted-foreground text-sm ml-1">
                  (optional for approval, required for rejection)
                </span>
              </Label>
              <Textarea
                id="comments"
                value={comments}
                onChange={(e) => {
                  setComments(e.target.value)
                  if (actionResult?.type === "error") {
                    setActionResult(null)
                  }
                }}
                placeholder="Add your comments here..."
                rows={4}
              />
            </div>
            <div className="flex gap-4">
              <Button onClick={handleApprove} disabled={isSubmitting} className="flex-1">
                <CheckCircle className="mr-2 h-4 w-4" />
                {isSubmitting ? "Processing..." : "Approve"}
              </Button>
              <Button onClick={handleReject} disabled={isSubmitting} variant="destructive" className="flex-1">
                <XCircle className="mr-2 h-4 w-4" />
                {isSubmitting ? "Processing..." : "Reject"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </ManagerLayout>
  )
}

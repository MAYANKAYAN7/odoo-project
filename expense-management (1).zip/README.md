# Expense Management System

A comprehensive expense management system built with Next.js 15, featuring role-based access control for Employees, Managers, and Admins.

## Features

### Employee Features
- Submit expense requests with receipts
- Track expense status (Draft, Pending, Approved, Rejected)
- View expense history and statistics
- Add comments and attachments to expenses

### Manager Features
- Review pending expense approvals
- Approve or reject expense requests
- View team expense statistics
- Add approval comments

### Admin Features
- View all expenses across the organization
- Override any approval decision in special cases
- Manage employees and managers
- View comprehensive expense analytics
- Track approval chains and audit trails

## Technology Stack

- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS v4
- **UI Components**: shadcn/ui
- **Icons**: Lucide React
- **State Management**: React Context API
- **Data**: Mock data (no database required)

## Prerequisites

Before you begin, ensure you have the following installed on your system:

- **Node.js**: Version 18.17 or higher
- **npm**: Version 9 or higher (comes with Node.js)
- **VS Code**: Latest version (recommended)

### Check Your Versions

Open your terminal and run:

\`\`\`bash
node --version
npm --version
\`\`\`

If you don't have Node.js installed, download it from [nodejs.org](https://nodejs.org/)

## Installation Steps

### Step 1: Download the Project

1. Download the project ZIP file
2. Extract it to your desired location
3. Open VS Code

### Step 2: Open Project in VS Code

1. Open VS Code
2. Click on **File** → **Open Folder**
3. Navigate to the extracted project folder and select it
4. Click **Select Folder**

### Step 3: Open Terminal in VS Code

1. In VS Code, press `` Ctrl + ` `` (backtick) or go to **Terminal** → **New Terminal**
2. Make sure you're in the project root directory

### Step 4: Install Dependencies

In the VS Code terminal, run:

\`\`\`bash
npm install
\`\`\`

This will install all required packages. It may take 2-3 minutes.

### Step 5: Run the Development Server

After installation completes, start the development server:

\`\`\`bash
npm run dev
\`\`\`

You should see output like:

\`\`\`
▲ Next.js 15.x.x
- Local:        http://localhost:3000
- Ready in 2.3s
\`\`\`

### Step 6: Open in Browser

1. Open your web browser
2. Navigate to: `http://localhost:3000`
3. You should see the login page

## Default User Credentials

The system uses mock data with the following test accounts:

### Admin Account
- **Email**: `admin@company.com`
- **Password**: `admin123`
- **Access**: Full system access, can override approvals

### Manager Account
- **Email**: `manager@company.com`
- **Password**: `manager123`
- **Access**: Review and approve/reject team expenses

### Employee Account
- **Email**: `employee@company.com`
- **Password**: `employee123`
- **Access**: Submit and track personal expenses

## Project Structure

\`\`\`
expense-management/
├── app/                          # Next.js App Router pages
│   ├── admin/                    # Admin dashboard and pages
│   │   ├── expenses/            # All expenses with override
│   │   ├── employees/           # Employee management
│   │   └── managers/            # Manager management
│   ├── manager/                  # Manager dashboard and pages
│   │   ├── pending/             # Pending approvals
│   │   └── team/                # Team expenses
│   ├── employee/                 # Employee dashboard and pages
│   │   ├── expenses/            # Personal expenses
│   │   └── submit/              # Submit new expense
│   ├── login/                    # Login page
│   ├── signup/                   # Signup page
│   └── page.tsx                  # Landing page
├── components/                   # React components
│   ├── ui/                      # shadcn/ui components
│   ├── admin-layout.tsx         # Admin layout wrapper
│   ├── employee-layout.tsx      # Employee layout wrapper
│   └── manager-layout.tsx       # Manager layout wrapper
├── lib/                          # Utility functions and data
│   ├── expenses-context.tsx     # Expense state management
│   ├── auth-context.tsx         # Authentication context
│   ├── mock-data.ts             # Mock data for testing
│   ├── types.ts                 # TypeScript type definitions
│   └── utils.ts                 # Utility functions
└── public/                       # Static assets
\`\`\`

## How to Use the System

### As an Employee

1. **Login** with employee credentials
2. **Submit Expense**:
   - Click "Submit Expense" in the navigation
   - Fill in expense details (title, amount, category, date)
   - Select a manager for approval
   - Add description and upload receipt (optional)
   - Click "Submit for Approval"
3. **Track Status**: View your expenses on the dashboard with status badges

### As a Manager

1. **Login** with manager credentials
2. **Review Pending Approvals**:
   - See pending expenses on the dashboard
   - Click "Pending Approvals" to view all
   - Click on an expense to review details
3. **Approve/Reject**:
   - Review expense details and receipt
   - Add comments (required for rejection)
   - Click "Approve" or "Reject"

### As an Admin

1. **Login** with admin credentials
2. **View All Expenses**:
   - Click "All Expenses" to see organization-wide expenses
   - Filter by status (All, Pending, Approved, Rejected)
3. **Override Decisions**:
   - Click "Override" on any expense
   - Select new status and add reason
   - Confirm override (marked in approval chain)
4. **Manage Users**:
   - View and manage employees and managers
   - See team statistics

## Development Commands

\`\`\`bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Run linting
npm run lint
\`\`\`

## Stopping the Server

To stop the development server:

1. Go to the VS Code terminal where the server is running
2. Press `Ctrl + C`
3. Confirm by typing `Y` if prompted

## Troubleshooting

### Port Already in Use

If port 3000 is already in use:

\`\`\`bash
# Run on a different port
npm run dev -- -p 3001
\`\`\`

Then open `http://localhost:3001`

### Dependencies Installation Failed

Try clearing npm cache:

\`\`\`bash
npm cache clean --force
npm install
\`\`\`

### Page Not Loading

1. Make sure the development server is running
2. Check the terminal for any error messages
3. Try refreshing the browser (Ctrl + F5)
4. Clear browser cache and cookies

### TypeScript Errors

If you see TypeScript errors in VS Code:

1. Restart VS Code
2. Run: `npm run build` to check for errors
3. Make sure all dependencies are installed

## Browser Compatibility

- Chrome (recommended)
- Firefox
- Safari
- Edge

## VS Code Extensions (Recommended)

For the best development experience, install these VS Code extensions:

1. **ES7+ React/Redux/React-Native snippets**
2. **Tailwind CSS IntelliSense**
3. **TypeScript Vue Plugin (Volar)**
4. **Prettier - Code formatter**
5. **ESLint**

## Notes

- This is a **demo application** using mock data
- No real database is required
- Data resets when the server restarts
- For production use, integrate with a real database (Supabase, PostgreSQL, etc.)

## Future Enhancements

- Real database integration
- Email notifications
- Receipt OCR scanning
- Export to PDF/Excel
- Multi-currency support
- Expense categories customization
- Budget tracking and alerts

## Support

If you encounter any issues:

1. Check the troubleshooting section above
2. Review the terminal output for error messages
3. Ensure all prerequisites are installed correctly

## License

This project is for educational and demonstration purposes.

---

**Happy Expense Managing! 🚀**

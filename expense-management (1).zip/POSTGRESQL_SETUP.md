# PostgreSQL Backend Setup Guide

This guide will help you set up PostgreSQL as the backend database for the Expense Management System.

## Prerequisites

- Node.js 18+ installed
- PostgreSQL database (choose one option below)

## Database Options

### Option 1: Neon (Recommended - Serverless PostgreSQL)

1. **Create a Neon account**
   - Go to [https://neon.tech](https://neon.tech)
   - Sign up for a free account
   - Create a new project

2. **Get your connection string**
   - Copy the connection string from your Neon dashboard
   - It looks like: `postgresql://user:password@host.neon.tech/dbname`

3. **Add to your project**
   \`\`\`bash
   # Create .env.local file in your project root
   echo "DATABASE_URL=your_neon_connection_string" > .env.local
   \`\`\`

### Option 2: Supabase (PostgreSQL + Auth + Storage)

1. **Create a Supabase project**
   - Go to [https://supabase.com](https://supabase.com)
   - Create a new project

2. **Get your connection string**
   - Go to Project Settings → Database
   - Copy the connection string (URI format)

3. **Add to your project**
   \`\`\`bash
   echo "DATABASE_URL=your_supabase_connection_string" > .env.local
   \`\`\`

### Option 3: Local PostgreSQL

1. **Install PostgreSQL**
   \`\`\`bash
   # macOS
   brew install postgresql
   brew services start postgresql

   # Ubuntu/Debian
   sudo apt-get install postgresql
   sudo service postgresql start

   # Windows - Download from postgresql.org
   \`\`\`

2. **Create a database**
   \`\`\`bash
   psql postgres
   CREATE DATABASE expense_management;
   \q
   \`\`\`

3. **Add to your project**
   \`\`\`bash
   echo "DATABASE_URL=postgresql://localhost:5432/expense_management" > .env.local
   \`\`\`

## Setup Steps

### 1. Install Dependencies

The `@neondatabase/serverless` package is already included in package.json:

\`\`\`bash
npm install
\`\`\`

### 2. Run Database Migrations

Execute the SQL scripts to create tables and seed initial data:

**Option A: Using psql (Command Line)**
\`\`\`bash
# Connect to your database
psql $DATABASE_URL

# Run the migration scripts
\i scripts/01-create-tables.sql
\i scripts/02-seed-data.sql
\q
\`\`\`

**Option B: Using Database GUI (Neon/Supabase Dashboard)**
1. Open your database dashboard
2. Go to SQL Editor
3. Copy and paste the contents of `scripts/01-create-tables.sql`
4. Execute the script
5. Repeat for `scripts/02-seed-data.sql`

**Option C: Using Node.js Script**
\`\`\`bash
# Create a migration runner script
node -e "
const { neon } = require('@neondatabase/serverless');
const fs = require('fs');
const sql = neon(process.env.DATABASE_URL);

async function migrate() {
  const createTables = fs.readFileSync('scripts/01-create-tables.sql', 'utf8');
  const seedData = fs.readFileSync('scripts/02-seed-data.sql', 'utf8');
  
  await sql.unsafe(createTables);
  console.log('✓ Tables created');
  
  await sql.unsafe(seedData);
  console.log('✓ Data seeded');
}

migrate().catch(console.error);
"
\`\`\`

### 3. Verify Setup

Start the development server:
\`\`\`bash
npm run dev
\`\`\`

Open [http://localhost:3000](http://localhost:3000) and try logging in with:
- **Admin**: admin@company.com / admin123
- **Manager**: manager@company.com / manager123
- **Employee**: employee@company.com / employee123

## Database Schema

### Tables Created

1. **users** - User accounts with roles (admin, manager, employee)
2. **expenses** - Expense records with amounts, categories, and status
3. **approval_steps** - Approval workflow steps for each expense
4. **approval_rules** - Configurable approval rules based on conditions
5. **audit_logs** - Activity logs for compliance and tracking
6. **settings** - System-wide configuration settings

### Indexes

Performance indexes are automatically created on:
- `expenses.employee_id`
- `expenses.status`
- `approval_steps.expense_id`
- `approval_steps.approver_id`
- `audit_logs.user_id`
- `audit_logs.entity_type`

## Environment Variables

Required environment variable:

\`\`\`env
DATABASE_URL=postgresql://user:password@host:port/database
\`\`\`

## Troubleshooting

### Connection Issues

**Error: "Connection refused"**
- Check if PostgreSQL is running
- Verify the connection string is correct
- Ensure firewall allows connections

**Error: "SSL required"**
- Add `?sslmode=require` to your connection string
- Example: `postgresql://user:pass@host/db?sslmode=require`

### Migration Issues

**Error: "Table already exists"**
- The scripts use `CREATE TABLE IF NOT EXISTS`
- Safe to run multiple times
- To reset: Drop all tables and re-run migrations

**Error: "Permission denied"**
- Ensure your database user has CREATE privileges
- For local PostgreSQL: `GRANT ALL PRIVILEGES ON DATABASE expense_management TO your_user;`

### Data Issues

**No users showing up**
- Check if seed data ran successfully
- Manually insert a test user:
  \`\`\`sql
  INSERT INTO users (id, email, password_hash, name, role, created_at, updated_at)
  VALUES ('test-1', 'test@test.com', 'hash', 'Test User', 'admin', NOW(), NOW());
  \`\`\`

## Upgrading from Mock Data

The system automatically uses PostgreSQL when `DATABASE_URL` is set. No code changes needed!

**Before (Mock Data):**
- Data stored in memory
- Resets on server restart
- No persistence

**After (PostgreSQL):**
- Data persisted in database
- Survives server restarts
- Production-ready

## Production Deployment

### Vercel + Neon (Recommended)

1. **Deploy to Vercel**
   \`\`\`bash
   vercel deploy
   \`\`\`

2. **Add environment variable**
   - Go to Vercel Dashboard → Project Settings → Environment Variables
   - Add `DATABASE_URL` with your Neon connection string
   - Redeploy

### Other Platforms

Ensure your hosting platform:
- Supports Node.js 18+
- Allows PostgreSQL connections
- Can set environment variables

## Security Best Practices

1. **Never commit .env.local** - Already in .gitignore
2. **Use strong passwords** - Change default user passwords
3. **Enable SSL** - Use `?sslmode=require` in production
4. **Rotate credentials** - Regularly update database passwords
5. **Limit permissions** - Use read-only users where possible

## Next Steps

- [ ] Change default user passwords
- [ ] Configure email notifications
- [ ] Set up automated backups
- [ ] Add monitoring and alerts
- [ ] Review and adjust approval rules
- [ ] Customize company settings

## Support

For issues or questions:
- Check the main README.md
- Review Neon documentation: https://neon.tech/docs
- Review Next.js documentation: https://nextjs.org/docs

# Backend Setup Guide

This expense management system now has a **separate backend** built with Next.js server capabilities.

## Architecture Overview

\`\`\`
Frontend (React Components)
    ↓
Server Actions (lib/actions/)
    ↓
Database Layer (lib/server/db.ts)
    ↓
In-Memory Storage (can be replaced with real DB)
\`\`\`

## Backend Components

### 1. Database Layer (`lib/server/db.ts`)
- Simulates a database with in-memory storage
- Provides CRUD operations for all entities
- **Easy to replace** with real database (Supabase, PostgreSQL, MongoDB, etc.)

### 2. Server Actions (`lib/actions/`)
- **Authentication** (`auth.ts`): Login, logout, signup, session management
- **Expenses** (`expenses.ts`): Create, read, update, approve, reject expenses
- **Users** (`users.ts`): User management (admin only)

### 3. API Routes (`app/api/`)
- RESTful endpoints for external integrations
- `/api/expenses` - Get all expenses
- `/api/expenses/[id]` - Get specific expense
- `/api/users` - Get all users

## How It Works

### Authentication Flow
\`\`\`typescript
// User logs in
login(email, password) → Sets HTTP-only cookie → Returns user data

// Check current user
getCurrentUser() → Reads cookie → Returns user or null

// Logout
logout() → Deletes cookie
\`\`\`

### Expense Workflow
\`\`\`typescript
// Employee creates expense
createExpense() → Validates user → Creates expense with approval chain

// Manager approves/rejects
approveExpense() → Checks permissions → Updates approval chain

// Admin overrides
overrideExpenseStatus() → Admin only → Overrides any decision
\`\`\`

## Running the Backend

The backend runs automatically with Next.js:

\`\`\`bash
npm run dev
\`\`\`

This starts:
- Frontend on `http://localhost:3000`
- Backend API routes on `http://localhost:3000/api/*`
- Server actions (called automatically from frontend)

## Testing the Backend

### Using the UI
1. Login with default credentials (see README.md)
2. All actions now use the backend automatically

### Using API Routes (Optional)
\`\`\`bash
# Get all expenses (requires authentication cookie)
curl http://localhost:3000/api/expenses

# Get specific expense
curl http://localhost:3000/api/expenses/exp-1
\`\`\`

## Upgrading to Real Database

### Option 1: Supabase (Recommended)

1. Install Supabase:
\`\`\`bash
npm install @supabase/supabase-js @supabase/ssr
\`\`\`

2. Create `.env.local`:
\`\`\`env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_key
\`\`\`

3. Replace `lib/server/db.ts` with Supabase client:
\`\`\`typescript
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

export const db = {
  users: {
    findAll: async () => {
      const { data } = await supabase.from('users').select('*')
      return data || []
    },
    // ... other methods
  }
}
\`\`\`

### Option 2: PostgreSQL with Prisma

1. Install Prisma:
\`\`\`bash
npm install @prisma/client
npm install -D prisma
npx prisma init
\`\`\`

2. Define schema in `prisma/schema.prisma`

3. Replace `lib/server/db.ts` with Prisma client

### Option 3: MongoDB

1. Install MongoDB driver:
\`\`\`bash
npm install mongodb
\`\`\`

2. Replace `lib/server/db.ts` with MongoDB operations

## Security Features

- **HTTP-only cookies** for session management
- **Server-side validation** for all operations
- **Role-based access control** (RBAC)
- **Authorization checks** in every server action

## Current Limitations

- **In-memory storage**: Data resets on server restart
- **Simple authentication**: No password hashing (add bcrypt in production)
- **No file uploads**: Receipt storage not implemented yet

## Next Steps

1. ✅ Backend infrastructure created
2. ⏳ Add real database (Supabase/PostgreSQL)
3. ⏳ Implement password hashing (bcrypt)
4. ⏳ Add file upload for receipts (Vercel Blob)
5. ⏳ Add email notifications
6. ⏳ Add API rate limiting

## API Documentation

### Server Actions (Recommended)

\`\`\`typescript
// Import in your components
import { login, logout, getCurrentUser } from '@/lib/actions/auth'
import { getExpenses, createExpense, approveExpense } from '@/lib/actions/expenses'

// Use in server components or with useTransition
const expenses = await getExpenses()
\`\`\`

### REST API (Optional)

All API routes require authentication cookie:

- `GET /api/expenses` - List all expenses
- `GET /api/expenses/[id]` - Get expense details
- `GET /api/users` - List all users (admin only)

## Troubleshooting

**Data not persisting?**
- This is expected with in-memory storage
- Upgrade to a real database for persistence

**Authentication not working?**
- Check if cookies are enabled
- Verify you're using the correct credentials

**Permission errors?**
- Check user role in the database
- Verify authorization logic in server actions

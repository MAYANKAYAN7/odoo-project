"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import type { Expense } from "./types"
import { mockExpenses } from "./mock-data"

interface ExpensesContextType {
  expenses: Expense[]
  addExpense: (expense: Omit<Expense, "id" | "createdAt" | "updatedAt">) => void
  updateExpense: (id: string, updates: Partial<Expense>) => void
  deleteExpense: (id: string) => void
}

const ExpensesContext = createContext<ExpensesContextType | undefined>(undefined)

export function ExpensesProvider({ children }: { children: React.ReactNode }) {
  const [expenses, setExpenses] = useState<Expense[]>([])

  // Load expenses from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem("expenses")
    if (stored) {
      try {
        const parsed = JSON.parse(stored)
        // Convert date strings back to Date objects
        const expensesWithDates = parsed.map((exp: any) => ({
          ...exp,
          date: new Date(exp.date),
          createdAt: new Date(exp.createdAt),
          updatedAt: new Date(exp.updatedAt),
          approvalChain: exp.approvalChain.map((step: any) => ({
            ...step,
            timestamp: step.timestamp ? new Date(step.timestamp) : undefined,
          })),
        }))
        setExpenses(expensesWithDates)
      } catch (error) {
        console.error("Failed to parse stored expenses:", error)
        setExpenses(mockExpenses)
      }
    } else {
      setExpenses(mockExpenses)
    }
  }, [])

  // Save expenses to localStorage whenever they change
  useEffect(() => {
    if (expenses.length > 0) {
      localStorage.setItem("expenses", JSON.stringify(expenses))
    }
  }, [expenses])

  const addExpense = (expenseData: Omit<Expense, "id" | "createdAt" | "updatedAt">) => {
    const newExpense: Expense = {
      ...expenseData,
      id: `exp-${Date.now()}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    setExpenses((prev) => [newExpense, ...prev])
  }

  const updateExpense = (id: string, updates: Partial<Expense>) => {
    setExpenses((prev) =>
      prev.map((exp) =>
        exp.id === id
          ? {
              ...exp,
              ...updates,
              updatedAt: new Date(),
            }
          : exp,
      ),
    )
  }

  const deleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((exp) => exp.id !== id))
  }

  return (
    <ExpensesContext.Provider value={{ expenses, addExpense, updateExpense, deleteExpense }}>
      {children}
    </ExpensesContext.Provider>
  )
}

export function useExpenses() {
  const context = useContext(ExpensesContext)
  if (context === undefined) {
    throw new Error("useExpenses must be used within an ExpensesProvider")
  }
  return context
}

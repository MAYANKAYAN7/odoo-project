// User roles
export type UserRole = "admin" | "manager" | "employee"

// User interface
export interface User {
  id: string
  email: string
  name: string
  role: UserRole
  department?: string
  managerId?: string
  profilePhoto?: string
  phone?: string
  createdAt: Date
  updatedAt: Date
}

// Expense status
export type ExpenseStatus = "draft" | "pending" | "approved" | "rejected" | "paid"

// Expense category
export type ExpenseCategory =
  | "travel"
  | "meals"
  | "accommodation"
  | "transportation"
  | "office_supplies"
  | "software"
  | "other"

// Expense interface
export interface Expense {
  id: string
  employeeId: string
  employeeName: string
  amount: number
  currency: string
  category: ExpenseCategory
  description: string
  date: Date
  status: ExpenseStatus
  receiptUrl?: string
  approvalChain: ApprovalStep[]
  createdAt: Date
  updatedAt: Date
}

// Approval step
export interface ApprovalStep {
  approverId: string
  approverName: string
  status: "pending" | "approved" | "rejected"
  comments?: string
  timestamp?: Date
}

// Approval rule condition
export type RuleCondition = "amount_greater_than" | "category_equals" | "department_equals"

// Approval rule
export interface ApprovalRule {
  id: string
  name: string
  priority: number
  conditions: {
    type: RuleCondition
    value: string | number
  }[]
  approvers: string[] // User IDs
  requireAllApprovals: boolean
  isActive: boolean
  createdAt: Date
  updatedAt: Date
}

// Audit log action
export type AuditAction =
  | "user_created"
  | "user_updated"
  | "user_deleted"
  | "expense_created"
  | "expense_updated"
  | "expense_approved"
  | "expense_rejected"
  | "rule_created"
  | "rule_updated"
  | "rule_deleted"
  | "settings_updated"

// Audit log entry
export interface AuditLog {
  id: string
  userId: string
  userName: string
  action: "create" | "update" | "delete" | "approve" | "reject"
  entityType: "expense" | "user" | "approval_rule" | "settings"
  entityId: string
  details: string
  timestamp: Date
  ipAddress: string
}

// Settings
export interface Settings {
  companyName: string
  defaultCurrency: string
  supportedCurrencies: string[]
  maxExpenseAmount: number
  requireReceipts: boolean
  receiptRequiredAmount: number
  autoApprovalThreshold: number
  fiscalYearStart: string // MM-DD format
  notificationEmail: string
  updatedAt: Date
}

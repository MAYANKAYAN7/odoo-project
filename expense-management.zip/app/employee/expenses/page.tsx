"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useExpenses } from "@/lib/expenses-context"
import { EmployeeLayout } from "@/components/employee-layout"
import type { Expense } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter } from "lucide-react"

export default function ExpensesPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()
  const { expenses: allExpenses } = useExpenses()
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "employee")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    if (user) {
      setExpenses(allExpenses.filter((e) => e.employeeId === user.id))
    }
  }, [user, allExpenses])

  if (isLoading || !user) {
    return null
  }

  const filteredExpenses = expenses.filter((expense) => {
    const matchesSearch =
      expense.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      expense.category.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || expense.status === statusFilter
    return matchesSearch && matchesStatus
  })

  return (
    <EmployeeLayout currentPage="/employee/expenses">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">My Expenses</h1>
          <p className="text-muted-foreground mt-1">View and track your expense reports</p>
        </div>

        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search expenses..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-4">
          {filteredExpenses.map((expense) => (
            <Card key={expense.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <CardTitle className="text-lg">{expense.description}</CardTitle>
                    <CardDescription>
                      {expense.date.toLocaleDateString()} • {expense.category}
                    </CardDescription>
                  </div>
                  <div className="text-right space-y-2">
                    <p className="text-xl font-bold">
                      ${expense.amount.toFixed(2)} {expense.currency}
                    </p>
                    <Badge
                      variant={
                        expense.status === "approved"
                          ? "default"
                          : expense.status === "rejected"
                            ? "destructive"
                            : "secondary"
                      }
                    >
                      {expense.status}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm font-medium mb-2">Approval Status:</p>
                    <div className="space-y-2">
                      {expense.approvalChain.map((step, index) => (
                        <div key={index} className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">{step.approverName}</span>
                          <Badge
                            variant={
                              step.status === "approved"
                                ? "default"
                                : step.status === "rejected"
                                  ? "destructive"
                                  : "secondary"
                            }
                          >
                            {step.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                  {expense.approvalChain.some((step) => step.comments) && (
                    <div>
                      <p className="text-sm font-medium mb-1">Comments:</p>
                      {expense.approvalChain
                        .filter((step) => step.comments)
                        .map((step, index) => (
                          <p key={index} className="text-sm text-muted-foreground">
                            {step.comments}
                          </p>
                        ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
          {filteredExpenses.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground">No expenses found</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </EmployeeLayout>
  )
}

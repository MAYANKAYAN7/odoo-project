"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useAuth } from "@/lib/auth-context"
import { useExpenses } from "@/lib/expenses-context"
import { ManagerLayout } from "@/components/manager-layout"
import type { Expense } from "@/lib/types"
import { mockUsers } from "@/lib/mock-data"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter } from "lucide-react"

export default function PendingApprovalsPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()
  const { expenses: allExpenses } = useExpenses()
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState<string>("all")

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "manager")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    if (user) {
      const pending = allExpenses.filter((e) =>
        e.approvalChain.some((step) => step.approverId === user.id && step.status === "pending"),
      )
      setExpenses(pending)
    }
  }, [user, allExpenses])

  if (isLoading || !user) {
    return null
  }

  const filteredExpenses = expenses.filter((expense) => {
    const matchesSearch =
      expense.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      expense.category.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = categoryFilter === "all" || expense.category === categoryFilter
    return matchesSearch && matchesCategory
  })

  return (
    <ManagerLayout currentPage="/manager/pending">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Pending Approvals</h1>
          <p className="text-muted-foreground mt-1">Review and approve expense reports</p>
        </div>

        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search expenses..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="travel">Travel</SelectItem>
              <SelectItem value="meals">Meals</SelectItem>
              <SelectItem value="accommodation">Accommodation</SelectItem>
              <SelectItem value="transportation">Transportation</SelectItem>
              <SelectItem value="office_supplies">Office Supplies</SelectItem>
              <SelectItem value="software">Software</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-4">
          {filteredExpenses.map((expense) => {
            const employee = mockUsers.find((u) => u.id === expense.employeeId)
            return (
              <Card key={expense.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-lg">{expense.description}</CardTitle>
                      <CardDescription>
                        Submitted by {employee?.name} • {expense.date.toLocaleDateString()} • {expense.category}
                      </CardDescription>
                    </div>
                    <div className="text-right space-y-2">
                      <p className="text-xl font-bold">
                        ${expense.amount.toFixed(2)} {expense.currency}
                      </p>
                      <Badge variant="secondary">Pending Review</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Department: {employee?.department || "N/A"}</p>
                      <p className="text-sm text-muted-foreground">
                        Submitted: {expense.createdAt.toLocaleDateString()}
                      </p>
                    </div>
                    <Link href={`/manager/pending/${expense.id}`}>
                      <Button>Review Details</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            )
          })}
          {filteredExpenses.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground">No pending approvals found</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </ManagerLayout>
  )
}

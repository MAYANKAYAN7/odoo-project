"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useAuth } from "@/lib/auth-context"
import { useExpenses } from "@/lib/expenses-context"
import { ManagerLayout } from "@/components/manager-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { FileCheck, Clock, CheckCircle, XCircle } from "lucide-react"
import { mockUsers } from "@/lib/mock-data"

export default function ManagerDashboard() {
  const router = useRouter()
  const { user, isLoading } = useAuth()
  const { expenses } = useExpenses()

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "manager")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return null
  }

  const pendingExpenses = expenses.filter((e) => {
    return e.approvalChain.some((step) => step.approverId === user.id && step.status === "pending")
  })

  const approvedByMe = expenses.filter((e) =>
    e.approvalChain.some((step) => step.approverId === user.id && step.status === "approved"),
  )
  const rejectedByMe = expenses.filter((e) =>
    e.approvalChain.some((step) => step.approverId === user.id && step.status === "rejected"),
  )

  const stats = [
    {
      title: "Pending Approvals",
      value: pendingExpenses.length,
      icon: Clock,
      description: "Awaiting your review",
      color: "text-yellow-600",
    },
    {
      title: "Approved",
      value: approvedByMe.length,
      icon: CheckCircle,
      description: "This month",
      color: "text-green-600",
    },
    {
      title: "Rejected",
      value: rejectedByMe.length,
      icon: XCircle,
      description: "This month",
      color: "text-red-600",
    },
    {
      title: "Total Reviewed",
      value: approvedByMe.length + rejectedByMe.length,
      icon: FileCheck,
      description: "All time",
      color: "text-blue-600",
    },
  ]

  return (
    <ManagerLayout currentPage="/manager">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground mt-1">Welcome back, {user.name}</p>
          </div>
          <Link href="/manager/pending">
            <Button>
              <FileCheck className="mr-2 h-4 w-4" />
              Review Expenses
            </Button>
          </Link>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => {
            const Icon = stat.icon
            return (
              <Card key={stat.title}>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
                  <Icon className={`h-4 w-4 ${stat.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <p className="text-xs text-muted-foreground mt-1">{stat.description}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Pending Approvals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {pendingExpenses.slice(0, 5).map((expense) => {
                const employee = mockUsers.find((u) => u.id === expense.employeeId)
                return (
                  <div
                    key={expense.id}
                    className="flex items-center justify-between border-b border-border pb-4 last:border-0 last:pb-0"
                  >
                    <div className="space-y-1">
                      <p className="text-sm font-medium">{expense.description}</p>
                      <div className="flex items-center gap-2">
                        <p className="text-xs text-muted-foreground">
                          {employee?.name} • {expense.date.toLocaleDateString()} • {expense.category}
                        </p>
                        <Badge variant="secondary">Pending</Badge>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <p className="text-sm font-medium">
                        ${expense.amount.toFixed(2)} {expense.currency}
                      </p>
                      <Link href={`/manager/pending/${expense.id}`}>
                        <Button size="sm">Review</Button>
                      </Link>
                    </div>
                  </div>
                )
              })}
              {pendingExpenses.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">No pending approvals</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </ManagerLayout>
  )
}

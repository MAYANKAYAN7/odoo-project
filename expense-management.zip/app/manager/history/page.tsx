"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useExpenses } from "@/lib/expenses-context"
import { ManagerLayout } from "@/components/manager-layout"
import type { Expense } from "@/lib/types"
import { mockUsers } from "@/lib/mock-data"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter } from "lucide-react"

export default function ApprovalHistoryPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()
  const { expenses: allExpenses } = useExpenses()
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "manager")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    if (user) {
      const reviewed = allExpenses.filter((e) =>
        e.approvalChain.some(
          (step) => step.approverId === user.id && (step.status === "approved" || step.status === "rejected"),
        ),
      )
      setExpenses(reviewed)
    }
  }, [user, allExpenses])

  if (isLoading || !user) {
    return null
  }

  const filteredExpenses = expenses.filter((expense) => {
    const matchesSearch =
      expense.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      expense.category.toLowerCase().includes(searchTerm.toLowerCase())
    const myDecision = expense.approvalChain.find((step) => step.approverId === user.id)
    const matchesStatus = statusFilter === "all" || myDecision?.status === statusFilter
    return matchesSearch && matchesStatus
  })

  return (
    <ManagerLayout currentPage="/manager/history">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Approval History</h1>
          <p className="text-muted-foreground mt-1">View your past approval decisions</p>
        </div>

        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search expenses..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Decisions</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-4">
          {filteredExpenses.map((expense) => {
            const employee = mockUsers.find((u) => u.id === expense.employeeId)
            const myDecision = expense.approvalChain.find((step) => step.approverId === user.id)
            return (
              <Card key={expense.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-lg">{expense.description}</CardTitle>
                      <CardDescription>
                        {employee?.name} • {expense.date.toLocaleDateString()} • {expense.category}
                      </CardDescription>
                    </div>
                    <div className="text-right space-y-2">
                      <p className="text-xl font-bold">
                        ${expense.amount.toFixed(2)} {expense.currency}
                      </p>
                      <Badge variant={myDecision?.status === "approved" ? "default" : "destructive"}>
                        {myDecision?.status}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Your decision:</span>
                      <span className="font-medium">
                        {myDecision?.timestamp ? myDecision.timestamp.toLocaleDateString() : "N/A"}
                      </span>
                    </div>
                    {myDecision?.comments && (
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Your comments:</p>
                        <p className="text-sm mt-1">{myDecision.comments}</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          })}
          {filteredExpenses.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground">No approval history found</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </ManagerLayout>
  )
}

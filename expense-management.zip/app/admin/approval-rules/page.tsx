"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { AdminLayout } from "@/components/admin-layout"
import type { ApprovalRule, RuleCondition } from "@/lib/types"
import { mockApprovalRules, mockUsers } from "@/lib/mock-data"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Pencil, Trash2, X } from "lucide-react"

export default function ApprovalRulesPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()
  const [rules, setRules] = useState<ApprovalRule[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingRule, setEditingRule] = useState<ApprovalRule | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    priority: 1,
    conditions: [] as { type: RuleCondition; value: string | number }[],
    approvers: [] as string[],
    requireAllApprovals: false,
    isActive: true,
  })

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "admin")) {
      router.push("/login")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    setRules(mockApprovalRules)
  }, [])

  const managers = mockUsers.filter((u) => u.role === "manager" || u.role === "admin")

  const handleOpenDialog = (rule?: ApprovalRule) => {
    if (rule) {
      setEditingRule(rule)
      setFormData({
        name: rule.name,
        priority: rule.priority,
        conditions: rule.conditions,
        approvers: rule.approvers,
        requireAllApprovals: rule.requireAllApprovals,
        isActive: rule.isActive,
      })
    } else {
      setEditingRule(null)
      setFormData({
        name: "",
        priority: rules.length + 1,
        conditions: [],
        approvers: [],
        requireAllApprovals: false,
        isActive: true,
      })
    }
    setIsDialogOpen(true)
  }

  const handleSave = () => {
    if (editingRule) {
      setRules(
        rules.map((rule) => (rule.id === editingRule.id ? { ...rule, ...formData, updatedAt: new Date() } : rule)),
      )
    } else {
      const newRule: ApprovalRule = {
        id: `rule-${Date.now()}`,
        ...formData,
        createdAt: new Date(),
        updatedAt: new Date(),
      }
      setRules([...rules, newRule])
    }
    setIsDialogOpen(false)
  }

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this approval rule?")) {
      setRules(rules.filter((rule) => rule.id !== id))
    }
  }

  const handleToggleActive = (id: string) => {
    setRules(rules.map((rule) => (rule.id === id ? { ...rule, isActive: !rule.isActive } : rule)))
  }

  const addCondition = () => {
    setFormData({
      ...formData,
      conditions: [...formData.conditions, { type: "amount_greater_than", value: 0 }],
    })
  }

  const removeCondition = (index: number) => {
    setFormData({
      ...formData,
      conditions: formData.conditions.filter((_, i) => i !== index),
    })
  }

  const updateCondition = (index: number, field: "type" | "value", value: any) => {
    const newConditions = [...formData.conditions]
    if (field === "value" && newConditions[index].type === "amount_greater_than") {
      const numValue = Number.parseFloat(value)
      newConditions[index] = { ...newConditions[index], [field]: isNaN(numValue) ? 0 : numValue }
    } else {
      newConditions[index] = { ...newConditions[index], [field]: value }
    }
    setFormData({ ...formData, conditions: newConditions })
  }

  const toggleApprover = (approverId: string) => {
    if (formData.approvers.includes(approverId)) {
      setFormData({ ...formData, approvers: formData.approvers.filter((id) => id !== approverId) })
    } else {
      setFormData({ ...formData, approvers: [...formData.approvers, approverId] })
    }
  }

  if (isLoading || !user) {
    return null
  }

  const getConditionLabel = (condition: { type: RuleCondition; value: string | number }) => {
    switch (condition.type) {
      case "amount_greater_than":
        return `Amount > $${condition.value}`
      case "category_equals":
        return `Category = ${condition.value}`
      case "department_equals":
        return `Department = ${condition.value}`
      default:
        return ""
    }
  }

  return (
    <AdminLayout currentPage="/admin/approval-rules">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Approval Rules</h1>
            <p className="text-muted-foreground mt-1">Configure expense approval workflows</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => handleOpenDialog()}>
                <Plus className="mr-2 h-4 w-4" />
                Add Rule
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingRule ? "Edit Approval Rule" : "Add Approval Rule"}</DialogTitle>
                <DialogDescription>
                  {editingRule ? "Update approval rule configuration" : "Create a new approval rule"}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-6 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Rule Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="High Value Expenses"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Input
                    id="priority"
                    type="number"
                    min="1"
                    value={formData.priority.toString()}
                    onChange={(e) => {
                      const val = Number.parseInt(e.target.value)
                      setFormData({ ...formData, priority: isNaN(val) ? 1 : val })
                    }}
                  />
                  <p className="text-xs text-muted-foreground">Lower numbers = higher priority</p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>Conditions</Label>
                    <Button type="button" variant="outline" size="sm" onClick={addCondition}>
                      <Plus className="mr-2 h-3 w-3" />
                      Add Condition
                    </Button>
                  </div>
                  {formData.conditions.map((condition, index) => (
                    <div key={index} className="flex gap-2 items-start">
                      <Select
                        value={condition.type}
                        onValueChange={(value) => updateCondition(index, "type", value as RuleCondition)}
                      >
                        <SelectTrigger className="flex-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="amount_greater_than">Amount Greater Than</SelectItem>
                          <SelectItem value="category_equals">Category Equals</SelectItem>
                          <SelectItem value="department_equals">Department Equals</SelectItem>
                        </SelectContent>
                      </Select>
                      {condition.type === "amount_greater_than" ? (
                        <Input
                          type="number"
                          className="flex-1"
                          value={typeof condition.value === "number" ? condition.value.toString() : condition.value}
                          onChange={(e) => updateCondition(index, "value", e.target.value)}
                          placeholder="1000"
                        />
                      ) : (
                        <Input
                          className="flex-1"
                          value={condition.value}
                          onChange={(e) => updateCondition(index, "value", e.target.value)}
                          placeholder={condition.type === "category_equals" ? "travel" : "Engineering"}
                        />
                      )}
                      <Button type="button" variant="ghost" size="sm" onClick={() => removeCondition(index)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  {formData.conditions.length === 0 && (
                    <p className="text-sm text-muted-foreground">No conditions added yet</p>
                  )}
                </div>

                <div className="space-y-3">
                  <Label>Approvers</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {managers.map((manager) => (
                      <div
                        key={manager.id}
                        className={`flex items-center gap-2 rounded-lg border p-3 cursor-pointer transition-colors ${
                          formData.approvers.includes(manager.id)
                            ? "border-primary bg-primary/10"
                            : "border-border hover:bg-accent"
                        }`}
                        onClick={() => toggleApprover(manager.id)}
                      >
                        <input
                          type="checkbox"
                          checked={formData.approvers.includes(manager.id)}
                          onChange={() => toggleApprover(manager.id)}
                          className="h-4 w-4"
                        />
                        <div className="flex-1">
                          <p className="text-sm font-medium">{manager.name}</p>
                          <p className="text-xs text-muted-foreground">{manager.role}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Require All Approvals</Label>
                    <p className="text-xs text-muted-foreground">All selected approvers must approve</p>
                  </div>
                  <Switch
                    checked={formData.requireAllApprovals}
                    onCheckedChange={(checked) => setFormData({ ...formData, requireAllApprovals: checked })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Active</Label>
                    <p className="text-xs text-muted-foreground">Enable this rule</p>
                  </div>
                  <Switch
                    checked={formData.isActive}
                    onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSave}>Save Rule</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid gap-4">
          {rules
            .sort((a, b) => a.priority - b.priority)
            .map((rule) => (
              <Card key={rule.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <CardTitle>{rule.name}</CardTitle>
                        <Badge variant={rule.isActive ? "default" : "secondary"}>
                          {rule.isActive ? "Active" : "Inactive"}
                        </Badge>
                        <Badge variant="outline">Priority {rule.priority}</Badge>
                      </div>
                      <CardDescription>
                        {rule.requireAllApprovals ? "Requires all approvals" : "Requires any approval"}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Switch checked={rule.isActive} onCheckedChange={() => handleToggleActive(rule.id)} />
                      <Button variant="ghost" size="sm" onClick={() => handleOpenDialog(rule)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => handleDelete(rule.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm font-medium mb-2">Conditions:</p>
                      <div className="flex flex-wrap gap-2">
                        {rule.conditions.map((condition, index) => (
                          <Badge key={index} variant="outline">
                            {getConditionLabel(condition)}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-medium mb-2">Approvers:</p>
                      <div className="flex flex-wrap gap-2">
                        {rule.approvers.map((approverId) => {
                          const approver = managers.find((m) => m.id === approverId)
                          return (
                            <Badge key={approverId} variant="secondary">
                              {approver?.name || "Unknown"}
                            </Badge>
                          )
                        })}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
        </div>
      </div>
    </AdminLayout>
  )
}
